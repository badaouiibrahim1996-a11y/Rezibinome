import { useCallback, useEffect, useMemo, useRef, useState, type FormEvent, type ReactNode } from 'react';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import type { Session } from '@supabase/supabase-js';
import { ErrorBoundary } from '@/components/error-boundary';
import { Toaster } from '@/components/ui/toaster';
import { TooltipProvider } from '@/components/ui/tooltip';
import GroupSessionsPage from '@/pages/group-sessions';
import LoginPage from '@/pages/login';
import { compatibilityScore, findListedSubject, formatSupabaseError, isListedSubject, isMissingGenderColumn, normalizeSubjectName, OTHER_SUBJECT_FILTER, profileColumns, profileSchema, profileDateLabel, profileFromRow, STUDY_TYPES, SUBJECTS, subjectKey, UNIVERSITIES, WILAYAS, type Profile, type ProfileInput, type ProfileRow } from '@/lib/profiles';
import { supabase } from '@/lib/supabase';
import { Link, Route, Switch, useLocation, Router as WouterRouter } from 'wouter';
import { Activity, ArrowDownRight, ArrowRight, BookOpen, CalendarDays, Check, CheckCircle2, ChevronDown, Clock3, Download, GraduationCap, LogOut, Mail, MapPin, Menu, MoreHorizontal, Phone, Search, Send, Share2, ShieldCheck, SlidersHorizontal, Sparkles, Users, X } from 'lucide-react';

const queryClient = new QueryClient();

const subjects = SUBJECTS;
const wilayas = [...WILAYAS, 'Autre'];
const slots = ['Lun. matin', 'Lun. soir', 'Mar. matin', 'Mar. soir', 'Mer. matin', 'Mer. soir', 'Jeu. matin', 'Jeu. soir', 'Ven. matin', 'Ven. soir', 'Sam. matin', 'Sam. soir', 'Dim. matin', 'Dim. soir'];
type ContactRequestStatus = 'pending' | 'accepted' | 'declined';
type ContactRequest = {
  id: string;
  from_user: string;
  to_user: string;
  message: string | null;
  status: ContactRequestStatus;
  created_at: string;
};
type ContactDetails = {
  telegram: string | null;
  whatsapp: string | null;
  contact_email: string | null;
};
type StudySessionStatus = 'proposed' | 'accepted' | 'declined' | 'cancelled';
type StudySession = {
  id: string;
  requester: string;
  partner: string;
  subject: string;
  starts_at: string;
  note: string | null;
  status: StudySessionStatus;
};
type ContactMethod = 'telegram' | 'whatsapp' | 'contact_email';
type BlockRecord = { blocker: string; blocked: string };
type ReportReason = 'spam' | 'harcelement' | 'faux_profil' | 'autre';

function algeriaDateKey(date = new Date()) {
  const parts = new Intl.DateTimeFormat('en', {
    timeZone: 'Africa/Algiers',
    year: 'numeric',
    month: '2-digit',
    day: '2-digit',
  }).formatToParts(date);
  const part = (type: string) => parts.find((item) => item.type === type)?.value ?? '';
  return `${part('year')}-${part('month')}-${part('day')}`;
}

function algeriaLocalDateTimeToIso(date: string, time: string) {
  const [year, month, day] = date.split('-').map(Number);
  const [hour, minute] = time.split(':').map(Number);
  if (![year, month, day, hour, minute].every(Number.isFinite)) {
    throw new Error('Choisis une date et une heure valides.');
  }
  const targetUtc = Date.UTC(year, month - 1, day, hour, minute);
  let timestamp = targetUtc;
  for (let attempt = 0; attempt < 3; attempt += 1) {
    const parts = new Intl.DateTimeFormat('en', {
      timeZone: 'Africa/Algiers',
      year: 'numeric',
      month: '2-digit',
      day: '2-digit',
      hour: '2-digit',
      minute: '2-digit',
      hourCycle: 'h23',
    }).formatToParts(new Date(timestamp));
    const part = (type: string) => Number(parts.find((item) => item.type === type)?.value);
    const shownUtc = Date.UTC(part('year'), part('month') - 1, part('day'), part('hour'), part('minute'));
    timestamp += targetUtc - shownUtc;
  }
  return new Date(timestamp).toISOString();
}

function formatAlgeriaSessionDate(value: string, compact = false) {
  return new Intl.DateTimeFormat('fr-DZ', {
    timeZone: 'Africa/Algiers',
    hourCycle: 'h23',
    ...(compact
      ? { dateStyle: 'medium' as const, timeStyle: 'short' as const }
      : { weekday: 'long' as const, day: 'numeric' as const, month: 'long' as const, year: 'numeric' as const, hour: '2-digit' as const, minute: '2-digit' as const }),
  }).format(new Date(value));
}

function sharedSessionSubjects(own: Profile, partner: Profile) {
  if (own.allSubjects || partner.allSubjects) return [...subjects];
  return own.subjects.filter((subject) => partner.subjects.includes(subject));
}

function escapeCalendarText(value: string) {
  return value.replace(/\\/g, '\\\\').replace(/\r?\n/g, '\\n').replace(/,/g, '\\,').replace(/;/g, '\\;');
}

function downloadSessionCalendar(session: StudySession, partnerName: string) {
  const start = new Date(session.starts_at);
  const end = new Date(start.getTime() + 60 * 60 * 1000);
  const toCalendarDate = (date: Date) => date.toISOString().replace(/[-:]/g, '').replace(/\.\d{3}Z$/, 'Z');
  const description = [`Binôme : ${partnerName}`, session.note?.trim()].filter(Boolean).join('\n');
  const lines = [
    'BEGIN:VCALENDAR',
    'VERSION:2.0',
    'PRODID:-//ReziBinome DZ//Sessions//FR',
    'CALSCALE:GREGORIAN',
    'METHOD:PUBLISH',
    'BEGIN:VEVENT',
    `UID:${escapeCalendarText(session.id)}@rezibinome-dz`,
    `DTSTAMP:${toCalendarDate(new Date())}`,
    `DTSTART:${toCalendarDate(start)}`,
    `DTEND:${toCalendarDate(end)}`,
    `SUMMARY:${escapeCalendarText(`Révision — ${session.subject}`)}`,
    `DESCRIPTION:${escapeCalendarText(description)}`,
    'END:VEVENT',
    'END:VCALENDAR',
  ];
  const url = URL.createObjectURL(new Blob([lines.join('\r\n')], { type: 'text/calendar;charset=utf-8' }));
  const link = document.createElement('a');
  link.href = url;
  link.download = `session-revision-${start.toISOString().slice(0, 10)}.ics`;
  document.body.appendChild(link);
  link.click();
  link.remove();
  window.setTimeout(() => URL.revokeObjectURL(url), 1000);
}

function App() {
  const [session, setSession] = useState<Session | null>(null);
  const [authLoading, setAuthLoading] = useState(true);
  const [profiles, setProfiles] = useState<Profile[]>([]);
  const [profilesLoading, setProfilesLoading] = useState(false);
  const [profilesError, setProfilesError] = useState('');
  const [contact, setContact] = useState<Profile | null>(null);
  const [reportTarget, setReportTarget] = useState<Profile | null>(null);
  const [blockTarget, setBlockTarget] = useState<Profile | null>(null);
  const [contactRequests, setContactRequests] = useState<ContactRequest[]>([]);
  const [studySessions, setStudySessions] = useState<StudySession[]>([]);
  const [sessionsLoading, setSessionsLoading] = useState(false);
  const [sessionsError, setSessionsError] = useState('');
  const [blocks, setBlocks] = useState<BlockRecord[]>([]);
  const [blockedContactIds, setBlockedContactIds] = useState<string[]>([]);
  const [contactDetailsByUser, setContactDetailsByUser] = useState<Record<string, ContactDetails>>({});
  const [sessionTarget, setSessionTarget] = useState<Profile | null>(null);
  const [ownContacts, setOwnContacts] = useState<ContactDetails>({ telegram: '', whatsapp: '', contact_email: '' });
  const [ownContactsError, setOwnContactsError] = useState('');
  const [relationshipsLoading, setRelationshipsLoading] = useState(false);
  const [relationshipsError, setRelationshipsError] = useState('');
  const [notice, setNotice] = useState<{ message: string; tone: 'success' | 'error' } | null>(null);
  const lastActiveUser = useRef<string | null>(null);
  const relationshipLoadId = useRef(0);
  const sessionLoadId = useRef(0);
  const own = useMemo(
    () => profiles.find((profile) => profile.id === session?.user.id) ?? null,
    [profiles, session?.user.id],
  );
  const loadSessions = useCallback(async () => {
    const loadId = ++sessionLoadId.current;
    const userId = session?.user.id;
    if (!supabase || !userId) {
      setStudySessions([]);
      setSessionsLoading(false);
      setSessionsError('');
      return;
    }
    setSessionsLoading(true);
    setSessionsError('');
    const { data, error } = await supabase
      .from('sessions')
      .select('id,requester,partner,subject,starts_at,note,status')
      .or(`requester.eq.${userId},partner.eq.${userId}`)
      .order('starts_at', { ascending: true });
    if (sessionLoadId.current !== loadId) return;
    if (error) {
      setStudySessions([]);
      setSessionsError(formatSupabaseError(error));
    } else {
      setStudySessions((data ?? []) as StudySession[]);
    }
    setSessionsLoading(false);
  }, [session?.user.id]);

  useEffect(() => {
    if (!supabase) {
      setAuthLoading(false);
      return;
    }

    let mounted = true;
    void supabase.auth.getSession().then(({ data, error }) => {
      if (!mounted) return;
      if (error) setNotice({ message: formatSupabaseError(error), tone: 'error' });
      setSession(data.session);
      setAuthLoading(false);
    });
    const { data: { subscription } } = supabase.auth.onAuthStateChange((_event, nextSession) => {
      setSession(nextSession);
      setAuthLoading(false);
      if (!nextSession) setProfiles([]);
    });

    return () => {
      mounted = false;
      subscription.unsubscribe();
    };
  }, []);

  useEffect(() => {
    if (authLoading) return;
    if (!supabase) {
      setProfiles([]);
      setProfilesLoading(false);
      setProfilesError('La connexion Supabase n’est pas configurée pour ce site.');
      lastActiveUser.current = null;
      return;
    }

    let mounted = true;
    setProfilesLoading(true);
    setProfilesError('');
    void (async () => {
      const query = () => supabase.from('profiles').select(profileColumns()).order('created_at', { ascending: false });
      let result = await query();
      if (isMissingGenderColumn(result.error) && profileSchema.gender) {
        profileSchema.gender = false;
        result = await query();
      }
      return result;
    })()
      .then(({ data, error }) => {
        if (!mounted) return;
        if (error) {
          setProfiles([]);
          setProfilesError(formatSupabaseError(error));
        } else {
          setProfiles((data ?? []).map((row) => profileFromRow(row as unknown as ProfileRow)));
        }
        setProfilesLoading(false);
      })
      .catch((error: unknown) => {
        if (!mounted) return;
        setProfilesError(formatSupabaseError(error instanceof Error ? error : { message: String(error) }));
        setProfilesLoading(false);
      });

    return () => { mounted = false; };
  }, [authLoading, session?.user.id]);

  useEffect(() => {
    void loadSessions();
    return () => { sessionLoadId.current += 1; };
  }, [loadSessions]);

  useEffect(() => {
    const userId = session?.user.id;
    if (!supabase || !userId || lastActiveUser.current === userId) return;
    lastActiveUser.current = userId;
    let mounted = true;
    void supabase
      .from('profiles')
      .update({ last_active_at: new Date().toISOString() })
      .eq('user_id', userId)
      .then(({ error }) => {
        if (mounted && error) {
          setProfilesError(formatSupabaseError(error));
        }
      });
    return () => { mounted = false; };
  }, [session?.user.id]);

  useEffect(() => {
    const userId = session?.user.id;
    const loadId = ++relationshipLoadId.current;
    if (!userId || !supabase) {
      setContactRequests([]);
      setBlocks([]);
      setBlockedContactIds([]);
      setContactDetailsByUser({});
      setOwnContacts({ telegram: '', whatsapp: '', contact_email: '' });
      setOwnContactsError('');
      setRelationshipsLoading(false);
      setRelationshipsError('');
      return;
    }

    setRelationshipsLoading(true);
    setRelationshipsError('');
    setOwnContactsError('');
    void (async () => {
      const [requestsResult, blocksResult, ownContactsResult] = await Promise.all([
        supabase
          .from('contact_requests')
          .select('id,from_user,to_user,message,status,created_at')
          .or(`from_user.eq.${userId},to_user.eq.${userId}`)
          .order('created_at', { ascending: false }),
        supabase
          .from('blocks')
          .select('blocker,blocked')
          .or(`blocker.eq.${userId},blocked.eq.${userId}`),
        supabase
          .from('profile_contacts')
          .select('telegram,whatsapp,contact_email')
          .eq('user_id', userId)
          .maybeSingle(),
      ]);

      if (!ownContactsResult.error) {
        setOwnContacts({
          telegram: ownContactsResult.data?.telegram ?? '',
          whatsapp: ownContactsResult.data?.whatsapp ?? '',
          contact_email: ownContactsResult.data?.contact_email ?? '',
        });
      } else if (relationshipLoadId.current === loadId) {
        setOwnContactsError(formatSupabaseError(ownContactsResult.error));
      }

      const error = requestsResult.error ?? blocksResult.error ?? ownContactsResult.error;
      if (error) {
        if (relationshipLoadId.current === loadId) {
          setRelationshipsError(formatSupabaseError(error));
          setRelationshipsLoading(false);
        }
        return;
      }

      const nextRequests = (requestsResult.data ?? []) as ContactRequest[];
      const nextBlocks = (blocksResult.data ?? []) as BlockRecord[];
      const partnerIds = [...new Set(nextRequests
        .filter((request) => request.status === 'accepted')
        .map((request) => request.from_user === userId ? request.to_user : request.from_user)
        .filter((partnerId) => partnerId !== userId))];
      let nextContactDetails: Record<string, ContactDetails> = {};
      if (partnerIds.length > 0) {
        const { data, error: contactsError } = await supabase
          .from('profile_contacts')
          .select('user_id,telegram,whatsapp,contact_email')
          .in('user_id', partnerIds);
        if (contactsError) {
          if (relationshipLoadId.current === loadId) {
            setRelationshipsError(formatSupabaseError(contactsError));
            setRelationshipsLoading(false);
          }
          return;
        }
        nextContactDetails = Object.fromEntries((data ?? []).map((row) => {
          const entry = row as { user_id: string } & ContactDetails;
          return [entry.user_id, {
            telegram: entry.telegram,
            whatsapp: entry.whatsapp,
            contact_email: entry.contact_email,
          }];
        }));
      }

      if (relationshipLoadId.current !== loadId) return;
      setContactRequests(nextRequests);
      setBlocks(nextBlocks);
      setBlockedContactIds(nextBlocks.map((row) => row.blocker === userId ? row.blocked : row.blocker));
      setContactDetailsByUser(nextContactDetails);
      setRelationshipsLoading(false);
    })().catch((loadError: unknown) => {
      if (relationshipLoadId.current !== loadId) return;
      setRelationshipsError(formatSupabaseError(loadError instanceof Error ? loadError : { message: String(loadError) }));
      setRelationshipsLoading(false);
    });
  }, [session?.user.id]);

  const showNotice = useCallback((message: string, tone: 'success' | 'error' = 'success') => {
    setNotice({ message, tone });
  }, []);

  useEffect(() => {
    if (!notice) return;
    const timeout = window.setTimeout(() => setNotice(null), 4500);
    return () => window.clearTimeout(timeout);
  }, [notice]);

  const shareSite = useCallback(async () => {
    const url = new URL(import.meta.env.BASE_URL, window.location.origin).href;
    const shareData = {
      title: 'Binôme',
      text: 'Trouve ton binôme de révision pour le concours de résidanat.',
      url,
    };

    try {
      if (navigator.share) {
        await navigator.share(shareData);
        return;
      }
    } catch (error) {
      if (error instanceof Error && error.name === 'AbortError') return;
    }

    try {
      await navigator.clipboard.writeText(url);
      showNotice('Lien copié');
    } catch {
      showNotice('Impossible de copier le lien sur cet appareil.', 'error');
    }
  }, [showNotice]);

  const submitProfile = async (profile: ProfileInput) => {
    if (!supabase || !session?.user.id) throw new Error('Connecte-toi pour enregistrer ton profil.');
    const now = new Date().toISOString();
    const saveRow = () => supabase
      .from('profiles')
      .upsert({
        user_id: session.user.id,
        name: profile.firstName,
        wilaya: profile.wilaya,
        university: profile.university,
        subjects: profile.subjects,
        all_subjects: profile.allSubjects,
        level: profile.level,
        study_type: profile.studyType,
        availability: profile.availability,
        notes: profile.notes.trim(),
        updated_at: now,
        last_active_at: now,
        ...(profileSchema.gender ? { gender: profile.gender || null } : {}),
      }, { onConflict: 'user_id' })
      .select(profileColumns())
      .single();
    let { data, error } = await saveRow();
    if (isMissingGenderColumn(error) && profileSchema.gender) {
      profileSchema.gender = false;
      ({ data, error } = await saveRow());
    }
    if (error) throw new Error(formatSupabaseError(error));
    const savedProfile = profileFromRow(data as unknown as ProfileRow);
    setProfiles((current) => [
      savedProfile,
      ...current.filter((item) => item.id !== savedProfile.id),
    ]);
    if (!ownContactsError) {
      const { error: contactsError } = await supabase
        .from('profile_contacts')
        .upsert({
          user_id: session.user.id,
          telegram: profile.telegram.trim() || null,
          whatsapp: profile.whatsapp.trim() || null,
          contact_email: profile.contactEmail.trim() || null,
        }, { onConflict: 'user_id' });
      if (contactsError) throw new Error(formatSupabaseError(contactsError));
      setOwnContacts({
        telegram: profile.telegram.trim(),
        whatsapp: profile.whatsapp.trim(),
        contact_email: profile.contactEmail.trim(),
      });
      showNotice('Ton profil a été enregistré.');
    } else {
      showNotice('Ton profil a été enregistré. Tes coordonnées privées sont restées inchangées car elles n’ont pas pu être chargées.', 'error');
    }
  };

  const refreshRelationships = async () => {
    if (!supabase || !session?.user.id) return;
    const userId = session.user.id;
    const [requestsResult, blocksResult] = await Promise.all([
      supabase.from('contact_requests').select('id,from_user,to_user,message,status,created_at')
        .or(`from_user.eq.${userId},to_user.eq.${userId}`).order('created_at', { ascending: false }),
      supabase.from('blocks').select('blocker,blocked').or(`blocker.eq.${userId},blocked.eq.${userId}`),
    ]);
    if (requestsResult.error) throw new Error(formatSupabaseError(requestsResult.error));
    if (blocksResult.error) throw new Error(formatSupabaseError(blocksResult.error));
    const nextRequests = (requestsResult.data ?? []) as ContactRequest[];
    const nextBlocks = (blocksResult.data ?? []) as BlockRecord[];
    const partnerIds = [...new Set(nextRequests.filter((request) => request.status === 'accepted')
      .map((request) => request.from_user === userId ? request.to_user : request.from_user)
      .filter((partnerId) => partnerId !== userId))];
    let nextContactDetails: Record<string, ContactDetails> = {};
    if (partnerIds.length) {
      const { data, error } = await supabase.from('profile_contacts')
        .select('user_id,telegram,whatsapp,contact_email').in('user_id', partnerIds);
      if (error) throw new Error(formatSupabaseError(error));
      nextContactDetails = Object.fromEntries((data ?? []).map((row) => {
        const entry = row as { user_id: string } & ContactDetails;
        return [entry.user_id, { telegram: entry.telegram, whatsapp: entry.whatsapp, contact_email: entry.contact_email }];
      }));
    }
    setContactRequests(nextRequests);
    setBlocks(nextBlocks);
    setBlockedContactIds(nextBlocks.map((row) => row.blocker === userId ? row.blocked : row.blocker));
    setContactDetailsByUser(nextContactDetails);
    setRelationshipsError('');
  };

  const createStudySession = async (profile: Profile, date: string, time: string, subject: string, note: string) => {
    if (!supabase || !session?.user.id || !own) throw new Error('Connecte-toi pour proposer une session.');
    const acceptedRequest = contactRequests.some((request) =>
      request.status === 'accepted' &&
      ((request.from_user === session.user.id && request.to_user === profile.id) ||
        (request.to_user === session.user.id && request.from_user === profile.id)),
    );
    if (!acceptedRequest) throw new Error('Une demande de contact doit être acceptée avant de proposer une session.');
    if (note.length > 200) throw new Error('La note ne peut pas dépasser 200 caractères.');
    const allowedSubjects = sharedSessionSubjects(own, profile);
    if (!allowedSubjects.includes(subject)) throw new Error('Choisis une matière autorisée pour cette session.');
    const startsAt = algeriaLocalDateTimeToIso(date, time);
    if (new Date(startsAt).getTime() <= Date.now()) throw new Error('Choisis une date et une heure dans le futur.');
    const { error } = await supabase.from('sessions').insert({
      requester: session.user.id,
      partner: profile.id,
      subject,
      starts_at: startsAt,
      note: note.trim() || null,
      status: 'proposed',
    });
    if (error) throw new Error(formatSupabaseError(error));
    setSessionTarget(null);
    await loadSessions();
    showNotice('Ta proposition de session a été envoyée.');
  };

  const updateStudySession = async (studySession: StudySession, status: StudySessionStatus) => {
    if (!supabase) throw new Error('La connexion Supabase n’est pas configurée.');
    const { error } = await supabase.from('sessions').update({ status }).eq('id', studySession.id);
    if (error) throw new Error(formatSupabaseError(error));
    await loadSessions();
    showNotice(status === 'accepted'
      ? 'Session acceptée.'
      : status === 'declined'
        ? 'Proposition refusée.'
        : 'Session annulée.');
  };

  const sendContactRequest = async (profile: Profile, message: string) => {
    if (!supabase || !session?.user.id) throw new Error('Connecte-toi pour demander à contacter ce binôme.');
    if (message.length > 200) throw new Error('Le message ne peut pas dépasser 200 caractères.');
    const { error } = await supabase.from('contact_requests').insert({
      from_user: session.user.id,
      to_user: profile.id,
      message: message.trim() || null,
    });
    if (error) throw new Error(formatSupabaseError(error));
    await refreshRelationships();
    setContact(null);
    showNotice('Ta demande de contact a été envoyée.');
  };

  const updateContactRequest = async (request: ContactRequest, status: 'accepted' | 'declined') => {
    if (!supabase) throw new Error('La connexion Supabase n’est pas configurée.');
    const { error } = await supabase.from('contact_requests').update({ status }).eq('id', request.id);
    if (error) throw new Error(formatSupabaseError(error));
    await refreshRelationships();
    showNotice(status === 'accepted' ? 'Demande acceptée. Les coordonnées sont maintenant accessibles.' : 'Demande refusée.');
  };

  const cancelContactRequest = async (request: ContactRequest) => {
    if (!supabase || !session?.user.id) throw new Error('Connecte-toi pour annuler cette demande.');
    const { error } = await supabase.from('contact_requests').delete()
      .eq('id', request.id).eq('from_user', session.user.id).eq('status', 'pending');
    if (error) throw new Error(formatSupabaseError(error));
    await refreshRelationships();
    showNotice('Demande annulée.');
  };

  const submitReport = async (profile: Profile, reason: ReportReason, details: string) => {
    if (!supabase || !session?.user.id) throw new Error('Connecte-toi pour signaler ce profil.');
    if (details.length > 300) throw new Error('Les précisions ne peuvent pas dépasser 300 caractères.');
    const { error } = await supabase.from('reports').insert({
      reporter: session.user.id,
      reported: profile.id,
      reason,
      details: details.trim() || null,
    });
    if (error) throw new Error(formatSupabaseError(error));
    setReportTarget(null);
    showNotice('Signalement envoyé. Merci de nous avoir prévenus.');
  };

  const blockUser = async (profile: Profile) => {
    if (!supabase || !session?.user.id) throw new Error('Connecte-toi pour bloquer cet utilisateur.');
    const { error } = await supabase.from('blocks').insert({
      blocker: session.user.id,
      blocked: profile.id,
    });
    if (error) throw new Error(formatSupabaseError(error));
    await refreshRelationships();
    setBlockTarget(null);
    showNotice(`${profile.firstName} a été bloqué.`);
  };

  const unblockUser = async (blockedId: string) => {
    if (!supabase || !session?.user.id) throw new Error('Connecte-toi pour débloquer cet utilisateur.');
    const { error } = await supabase.from('blocks').delete()
      .eq('blocker', session.user.id).eq('blocked', blockedId);
    if (error) throw new Error(formatSupabaseError(error));
    await refreshRelationships();
    showNotice('Utilisateur débloqué.');
  };

  const deleteProfile = async () => {
    if (!supabase || !session?.user.id) throw new Error('Connecte-toi pour supprimer ton profil.');
    const { error } = await supabase.from('profiles').delete().eq('user_id', session.user.id);
    if (error) throw new Error(formatSupabaseError(error));
    setProfiles((current) => current.filter((profile) => profile.id !== session.user.id));
    showNotice('Profil supprimé. Ton compte reste actif.');
  };

  const deleteAccount = async () => {
    if (!supabase) throw new Error('La connexion Supabase n’est pas configurée.');
    const { error } = await supabase.rpc('delete_my_account');
    if (error) throw new Error(formatSupabaseError(error));
    const { error: signOutError } = await supabase.auth.signOut({ scope: 'local' });
    setSession(null);
    setProfiles([]);
    if (signOutError) throw new Error(formatSupabaseError(signOutError));
    showNotice('Ton compte a été supprimé.');
  };

  const signOut = async () => {
    if (!supabase) return;
    const { error } = await supabase.auth.signOut();
    if (error) {
      showNotice(formatSupabaseError(error), 'error');
      return;
    }
    setSession(null);
    setProfiles([]);
    showNotice('Tu es déconnecté.');
  };

  const ownProfileProps = {
    own,
    ownContacts,
    ownContactsError,
    blockedIds: blocks.filter((row) => row.blocker === session?.user.id).map((row) => row.blocked),
    blockedProfiles: blocks.filter((row) => row.blocker === session?.user.id)
      .map((row) => profiles.find((profile) => profile.id === row.blocked))
      .filter((profile): profile is Profile => Boolean(profile)),
    onSubmit: submitProfile,
    onDeleteProfile: deleteProfile,
    onDeleteAccount: deleteAccount,
    onUnblock: unblockUser,
  };

  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <WouterRouter base={import.meta.env.BASE_URL.replace(/\/$/, '')}>
          <RoutedErrorBoundary>
            <div className="app-frame">
              <Header session={session} onShare={shareSite} onSignOut={signOut} pendingRequests={contactRequests.filter((request) => request.to_user === session?.user.id && request.status === 'pending' && !blockedContactIds.includes(request.from_user)).length} />
              <Switch>
                <Route path="/" component={() => <Home own={own} onShare={shareSite} />} />
                <Route path="/login" component={() => authLoading ? <LoadingPage /> : session ? <SignedInPage onSignOut={signOut} /> : <LoginPage />} />
                <Route path="/profils" component={() => authLoading ? <LoadingPage /> : <Profiles profiles={profiles} own={own} requests={contactRequests} contactDetails={contactDetailsByUser} sessions={studySessions} blockedIds={blockedContactIds} relationshipsLoading={relationshipsLoading} relationshipsError={relationshipsError} onContact={setContact} onProposeSession={setSessionTarget} onReport={setReportTarget} onBlock={setBlockTarget} loading={profilesLoading} error={profilesError} />} />
                <Route path="/demandes" component={() => authLoading ? <LoadingPage /> : session ? <RequestsPage userId={session.user.id} requests={contactRequests} profiles={profiles} contactDetails={contactDetailsByUser} blockedIds={blockedContactIds} loading={relationshipsLoading} error={relationshipsError} onUpdate={updateContactRequest} onCancel={cancelContactRequest} /> : <LoginPage />} />
                <Route path="/sessions-ouvertes">{authLoading ? <LoadingPage /> : session ? <GroupSessionsPage userId={session.user.id} own={own} profiles={profiles} blockedIds={blockedContactIds} notify={showNotice} /> : <LoginPage />}</Route>
                <Route path="/sessions" component={() => authLoading ? <LoadingPage /> : session ? <SessionsPage userId={session.user.id} sessions={studySessions} profiles={profiles} blockedIds={blockedContactIds} loading={sessionsLoading} error={sessionsError} onUpdate={updateStudySession} /> : <LoginPage />} />
                <Route path="/mon-profil" component={() => authLoading ? <LoadingPage /> : session ? <ProfileForm key={own?.id ?? 'new-profile'} {...ownProfileProps} loading={profilesLoading || relationshipsLoading} onSignOut={signOut} /> : <LoginPage />} />
                <Route component={MissingRoute} />
              </Switch>
              <Footer />
              {notice && <div className={`toast-success ${notice.tone === 'error' ? 'toast-error' : ''}`} role={notice.tone === 'error' ? 'alert' : 'status'} data-testid="status-global-notice"><CheckCircle2 size={19} />{notice.message}<button className="icon-button" aria-label="Fermer la notification" onClick={() => setNotice(null)} data-testid="button-dismiss-notice"><X size={16} /></button></div>}
              {contact && <ContactDialog profile={contact} onClose={() => setContact(null)} onSubmit={sendContactRequest} />}
              {sessionTarget && own && <SessionDialog profile={sessionTarget} own={own} onClose={() => setSessionTarget(null)} onSubmit={createStudySession} />}
              {reportTarget && <ReportDialog profile={reportTarget} onClose={() => setReportTarget(null)} onSubmit={submitReport} />}
              {blockTarget && <BlockDialog profile={blockTarget} onClose={() => setBlockTarget(null)} onConfirm={() => blockUser(blockTarget)} />}
            </div>
          </RoutedErrorBoundary>
        </WouterRouter>
        <Toaster />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

function Header({
  session,
  onShare,
  onSignOut,
  pendingRequests,
}: {
  session: Session | null;
  onShare: () => Promise<void>;
  onSignOut: () => Promise<void>;
  pendingRequests: number;
}) {
  const [menuOpen, setMenuOpen] = useState(false);
  const [path] = useLocation();
  const links = [{ href: '/', label: 'Accueil' }, { href: '/profils', label: 'Trouver un binôme' }, { href: '/sessions-ouvertes', label: 'Sessions ouvertes' }, ...(session ? [{ href: '/demandes', label: 'Demandes' }, { href: '/sessions', label: 'Mes sessions' }] : []), { href: '/mon-profil', label: 'Mon profil' }];
  return <header className="site-header">
    <div className="nav-wrap">
      <Link href="/" className="brand" aria-label="Binôme, accueil" data-testid="link-brand">
        <span className="brand-mark"><BookOpen size={21} strokeWidth={2.3} /></span>
        <span className="brand-name">Binôme</span>
      </Link>
      <button className="menu-toggle icon-button" onClick={() => setMenuOpen(!menuOpen)} aria-label={menuOpen ? 'Fermer le menu' : 'Ouvrir le menu'} aria-expanded={menuOpen} data-testid="button-mobile-menu">{menuOpen ? <X size={22} /> : <Menu size={22} />}</button>
      <nav className={`nav-links menu-popover ${menuOpen ? 'is-open' : ''}`} aria-label="Navigation principale">
        {links.map((item) => <Link key={item.href} href={item.href} className={`nav-link ${path === item.href ? 'active' : ''}`} onClick={() => setMenuOpen(false)} data-testid={`link-nav-${item.href === '/' ? 'accueil' : item.href.slice(1)}`}>{item.label}{item.href === '/demandes' && pendingRequests > 0 && <span className="nav-badge" aria-label={`${pendingRequests} demande${pendingRequests > 1 ? 's' : ''} en attente`} data-testid="badge-pending-requests">{pendingRequests}</span>}</Link>)}
        <button className="menu-action" onClick={() => { setMenuOpen(false); void onShare(); }} data-testid="button-share-header"><Share2 size={17} /><span>Partager le site</span></button>
        {session
          ? <button className="menu-action menu-signout" onClick={() => { setMenuOpen(false); void onSignOut(); }} data-testid="button-sign-out"><LogOut size={17} /><span>Se déconnecter</span></button>
          : <Link href="/login" className="nav-cta" onClick={() => setMenuOpen(false)} data-testid="link-nav-login"><span>Se connecter</span><ArrowRight size={16} /></Link>}
      </nav>
    </div>
  </header>;
}

function Home({ own, onShare }: { own: Profile | null; onShare: () => Promise<void> }) {
  return <main>
    <section className="hero-section">
      <div className="hero-inner">
        <div className="hero-copy">
          {own && <p className="hero-welcome" data-testid="text-home-welcome">Bonjour {own.firstName}, content de te revoir.</p>}
          <div className="eyebrow"><span className="pulse-dot" /> LE CONCOURS, À DEUX C’EST MIEUX</div>
          <h1>Trouve ton binôme<br />de <span>révision</span></h1>
          <p className="hero-lede">Prépare le résidanat avec quelqu’un qui partage tes matières, ton rythme et tes ambitions.</p>
          <div className="hero-actions">
            <Link href="/profils" className="button-primary" data-testid="link-home-browse">Trouver mon binôme <ArrowRight size={18} /></Link>
            <Link href="/mon-profil" className="button-quiet" data-testid="link-home-profile">{own ? 'Mettre à jour mon profil' : 'Créer mon profil'} <ArrowDownRight size={17} /></Link>
          </div>
          <div className="hero-proof"><div className="avatar-stack"><span>AM</span><span>YS</span><span>LN</span><span>+</span></div><p><strong>Des étudiants, partout en Algérie.</strong><br />Une préparation qui avance ensemble.</p></div>
        </div>
        <div className="hero-visual" aria-label="Illustration de fiches de révision" data-testid="illustration-study">
          <div className="visual-orbit orbit-one"></div><div className="visual-orbit orbit-two"></div>
          <div className="study-note note-back"><div className="note-heading"><span className="note-dot"></span> À revoir cette semaine</div><div className="note-line long"></div><div className="note-line"></div><div className="note-line short"></div><div className="note-tag">Cardiologie</div></div>
          <div className="study-note note-front"><span className="mini-label">FICHE DU JOUR · 08</span><div className="heart-icon"><BookOpen size={25} /></div><h3>On révise<br />ensemble ?</h3><div className="note-rule"></div><div className="note-footer"><span>Session de révision</span><span className="check-circle"><Check size={14} /></span></div></div>
          <div className="floating-tag tag-top"><span className="tag-check"><Check size={13} /></span> Même objectif</div>
          <div className="floating-tag tag-bottom"><span className="tag-calendar"><CalendarDays size={16} /></span> Un créneau commun</div>
        </div>
      </div>
      <div className="hero-bottom"><span>01 / UNE PRÉPARATION PLUS HUMAINE</span><span className="hero-bottom-line"></span><span>À TON RYTHME, PRÈS DE CHEZ TOI</span></div>
    </section>
    <section className="intro-section">
      <div className="section-kicker">LE BON BINÔME CHANGE TOUT</div>
      <div className="intro-grid"><h2>Moins seul face<br />au programme.</h2><div className="intro-description"><p>Le concours de résidanat est un marathon. RéziBinôme t’aide à trouver un partenaire de révision compatible — selon ce que tu révises, tes disponibilités et ta wilaya.</p><Link href="/profils" className="text-link" data-testid="link-intro-browse">Voir les profils <ArrowRight size={17} /></Link><button className="button-quiet share-home" onClick={() => { void onShare(); }} data-testid="button-share-home"><Share2 size={16} />Partager le site</button></div></div>
    </section>
    <section className="steps-section">
      <div className="steps-heading"><div><div className="section-kicker">SIMPLE COMME BONJOUR</div><h2>Un binôme. Trois étapes.</h2></div><span className="step-count">01 — 03</span></div>
      <div className="steps-grid">
        <article className="step-card"><span className="step-number">01</span><div className="step-icon"><Users size={21} /></div><h3>Présente-toi</h3><p>Ta wilaya, les matières à revoir et le rythme qui te convient. Rien de plus.</p></article>
        <article className="step-card featured-step"><span className="step-number">02</span><div className="step-icon"><SlidersHorizontal size={21} /></div><h3>Repère l’accord</h3><p>Compare les matières et les créneaux pour trouver quelqu’un sur la même longueur d’onde.</p></article>
        <article className="step-card"><span className="step-number">03</span><div className="step-icon"><BookOpen size={21} /></div><h3>Commencez à réviser</h3><p>Un premier échange simulé dans le prototype. À vous d’imaginer la suite.</p></article>
      </div>
    </section>
    <section className="home-cta"><div className="cta-shape"></div><div className="cta-content"><div className="section-kicker light-kicker">CHAQUE JOUR COMPTE</div><h2>Et si tes prochaines<br />révisions étaient à deux ?</h2><Link href="/mon-profil" className="button-light" data-testid="link-home-cta">Créer mon profil <ArrowRight size={17} /></Link></div><div className="cta-side-note"><span className="cta-line"></span><p>Un profil. Des révisions<br />qui prennent un autre sens.</p></div></section>
  </main>;
}

function Profiles({
  profiles,
  own,
  requests,
  contactDetails,
  sessions,
  blockedIds,
  relationshipsLoading,
  relationshipsError,
  onContact,
  onProposeSession,
  onReport,
  onBlock,
  loading,
  error,
}: {
  profiles: Profile[];
  own: Profile | null;
  requests: ContactRequest[];
  contactDetails: Record<string, ContactDetails>;
  sessions: StudySession[];
  blockedIds: string[];
  relationshipsLoading: boolean;
  relationshipsError: string;
  onContact: (p: Profile) => void;
  onProposeSession: (p: Profile) => void;
  onReport: (p: Profile) => void;
  onBlock: (p: Profile) => void;
  loading: boolean;
  error: string;
}) {
  const [query, setQuery] = useState('');
  const [wilaya, setWilaya] = useState('');
  const [subject, setSubject] = useState('');
  const [time, setTime] = useState('');
  const [level, setLevel] = useState('');
  const [onlyMatches, setOnlyMatches] = useState(false);
  const [activeOnly, setActiveOnly] = useState(false);
  const [sort, setSort] = useState<'recent' | 'compatibility'>('recent');
  const [genderFilter, setGenderFilter] = useState('');
  const filtered = useMemo(() => profiles.filter((p) => {
    if ((own && p.id === own.id) || blockedIds.includes(p.id)) return false;
    const activeSince = Date.now() - 30 * 24 * 60 * 60 * 1000;
    const isActive = p.lastActiveAt !== null && new Date(p.lastActiveAt).getTime() >= activeSince;
    return (!query || `${p.firstName} ${p.wilaya} ${p.university}`.toLowerCase().includes(query.toLowerCase())) &&
      (!wilaya || p.wilaya === wilaya) && (!subject || (subject === OTHER_SUBJECT_FILTER ? p.subjects.some((s) => !isListedSubject(s)) : p.allSubjects || p.subjects.includes(subject))) &&
      (!time || p.availability.includes(time)) && (!level || p.level === level) &&
      (!onlyMatches || !own || compatibilityScore(p, own).total > 0) &&
      (!genderFilter || p.gender === genderFilter) &&
      (!activeOnly || isActive);
  }).sort((a, b) => {
    if (sort === 'compatibility' && own) {
      const difference = compatibilityScore(b, own).total - compatibilityScore(a, own).total;
      if (difference !== 0) return difference;
    }
    return new Date(b.createdAt ?? 0).getTime() - new Date(a.createdAt ?? 0).getTime();
  }), [profiles, own, blockedIds, query, wilaya, subject, time, level, onlyMatches, activeOnly, sort, genderFilter]);
  const reset = () => { setQuery(''); setWilaya(''); setSubject(''); setTime(''); setLevel(''); setOnlyMatches(false); setActiveOnly(false); setSort('recent'); setGenderFilter(''); };
  const activeFilters = Boolean(query || wilaya || subject || time || level || genderFilter || onlyMatches || activeOnly || sort !== 'recent');
  const visibleProfileCount = profiles.filter((profile) => profile.id !== own?.id && !blockedIds.includes(profile.id)).length;
  const nextSession = own
    ? sessions
      .filter((item) => item.status === 'accepted' && new Date(item.starts_at).getTime() >= Date.now())
      .filter((item) => !blockedIds.includes(item.requester === own.id ? item.partner : item.requester))
      .sort((a, b) => new Date(a.starts_at).getTime() - new Date(b.starts_at).getTime())[0]
    : undefined;
  const nextSessionPartner = nextSession
    ? profiles.find((profile) => profile.id === (nextSession.requester === own?.id ? nextSession.partner : nextSession.requester))
    : undefined;
  return <main className="browse-page">
    <section className="page-heading">
      <div className="page-heading-inner"><div><div className="eyebrow"><span className="pulse-dot" /> LA COMMUNAUTÉ RÉSIDANAT</div><h1>Ton prochain<br className="mobile-break" /> binôme est ici.</h1><p>Des étudiants qui avancent vers le même objectif, partout en Algérie.</p></div><div className="profile-count"><strong>{visibleProfileCount}</strong><span>profils<br />à découvrir</span><Users size={20} /></div></div>
    </section>
    {nextSession && <div className="next-session-banner" role="status" data-testid="banner-next-session">
      <CalendarDays size={19} />
      <p><strong>Prochaine session :</strong> {formatAlgeriaSessionDate(nextSession.starts_at, true)} avec {nextSessionPartner?.firstName ?? 'ton binôme'}</p>
      <Link className="text-link" href="/sessions" data-testid="link-next-session">Voir mes sessions <ArrowRight size={14} /></Link>
    </div>}
    <section className="browse-content">
      <div className="browse-title-row"><div><h2>Les profils</h2><p>{own ? 'Les profils les plus compatibles apparaissent en premier.' : 'Filtre les profils selon ce qui compte pour toi.'}</p></div><span className="result-count" data-testid="text-result-count">{filtered.length} résultat{filtered.length !== 1 ? 's' : ''}</span></div>
      <div className="filter-panel">
        <div className="filter-top"><div className="filter-title"><SlidersHorizontal size={17} /><strong>Affiner ma recherche</strong></div>{activeFilters && <button className="reset-button" onClick={reset} data-testid="button-reset-filters">Tout effacer</button>}</div>
        <div className="filter-grid">
          <label className="filter-field search-field"><span>Recherche</span><div className="input-wrap"><Search size={17} /><input value={query} onChange={(e) => setQuery(e.target.value)} placeholder="Prénom ou wilaya" aria-label="Rechercher un prénom ou une wilaya" data-testid="input-profile-search" /></div></label>
          <label className="filter-field"><span>Wilaya</span><select value={wilaya} onChange={(e) => setWilaya(e.target.value)} aria-label="Filtrer par wilaya" data-testid="select-filter-wilaya"><option value="">Toutes les wilayas</option>{wilayas.map((w) => <option key={w}>{w}</option>)}</select><ChevronDown className="select-chevron" size={16} /></label>
          <label className="filter-field"><span>Matière</span><select value={subject} onChange={(e) => setSubject(e.target.value)} aria-label="Filtrer par matière" data-testid="select-filter-subject"><option value="">Toutes les matières</option>{subjects.map((s) => <option key={s}>{s}</option>)}<option value={OTHER_SUBJECT_FILTER}>Autre</option></select><ChevronDown className="select-chevron" size={16} /></label>
          <label className="filter-field"><span>Disponibilité</span><select value={time} onChange={(e) => setTime(e.target.value)} aria-label="Filtrer par créneau" data-testid="select-filter-availability"><option value="">Tous les créneaux</option>{slots.map((s) => <option key={s}>{s}</option>)}</select><ChevronDown className="select-chevron" size={16} /></label>
          <label className="filter-field"><span>Préparation</span><select value={level} onChange={(e) => setLevel(e.target.value)} aria-label="Filtrer par niveau" data-testid="select-filter-level"><option value="">Tous les niveaux</option><option>Début de préparation</option><option>Rythme régulier</option><option>Révisions avancées</option></select><ChevronDown className="select-chevron" size={16} /></label>
          <label className="filter-field"><span>Sexe</span><select value={genderFilter} onChange={(e) => setGenderFilter(e.target.value)} aria-label="Filtrer par sexe" data-testid="select-filter-gender"><option value="">Tous</option><option value="male">Masculin</option><option value="female">Féminin</option></select><ChevronDown className="select-chevron" size={16} /></label>
          <label className="filter-field"><span>Trier par</span><select value={sort} onChange={(e) => setSort(e.target.value as 'recent' | 'compatibility')} aria-label="Trier les profils" data-testid="select-profile-sort"><option value="recent">Plus récents</option><option value="compatibility">Meilleure compatibilité</option></select><ChevronDown className="select-chevron" size={16} /></label>
        </div>
        {own ? <label className="match-toggle"><input type="checkbox" checked={onlyMatches} onChange={(e) => setOnlyMatches(e.target.checked)} data-testid="checkbox-only-matches" /><span className="custom-check"><Check size={12} /></span><span>Afficher uniquement les profils avec au moins un point commun</span><span className="toggle-hint">matières ou créneaux</span></label> :
          <div className="match-hint"><Sparkles size={16} /><span>Crée ton profil pour voir les correspondances avec tes matières et tes créneaux.</span><Link href="/mon-profil" data-testid="link-match-create">Créer mon profil <ArrowRight size={14} /></Link></div>}
        <label className="match-toggle activity-toggle"><input type="checkbox" checked={activeOnly} onChange={(e) => setActiveOnly(e.target.checked)} data-testid="checkbox-active-30-days" /><span className="custom-check"><Check size={12} /></span><Activity size={16} /><span>Actifs ces 30 jours</span></label>
      </div>
      {error && <div className="data-error" role="alert" data-testid="status-profiles-error">{error}</div>}
      {relationshipsError && <div className="data-error" role="alert" data-testid="status-relationships-error">{relationshipsError}</div>}
      {loading || (own && relationshipsLoading) ? <div className="loading-state" role="status" data-testid="status-profiles-loading">Chargement des profils…</div> :
        relationshipsError ? null : filtered.length ? <div className="profile-grid" data-testid="list-profiles">{filtered.map((profile) => <ProfileCard key={profile.id} profile={profile} own={own} requests={requests} contactDetails={contactDetails[profile.id]} onContact={onContact} onProposeSession={onProposeSession} onReport={onReport} onBlock={onBlock} />)}</div> :
          <div className="empty-state" data-testid="status-no-profiles"><div className="empty-icon"><Search size={25} /></div><h3>{profiles.length === 0 ? 'Aucun profil pour le moment' : 'Aucun profil ne correspond'}</h3><p>{profiles.length === 0 ? 'Crée ton profil pour commencer à trouver des binômes.' : 'Essaie d’élargir ta recherche ou de retirer quelques filtres.'}</p><Link className="button-primary" href={profiles.length === 0 ? '/mon-profil' : '/profils'} onClick={profiles.length > 0 ? reset : undefined} data-testid="button-empty-reset">{profiles.length === 0 ? 'Créer mon profil' : 'Effacer les filtres'} <ArrowRight size={16} /></Link></div>}
      <div className="privacy-note"><ShieldCheck size={17} /><span>Les profils sont lus depuis ton espace Supabase. Les coordonnées restent privées.</span></div>
    </section>
  </main>;
}

function ProfileCard({
  profile,
  own,
  requests,
  contactDetails,
  onContact,
  onProposeSession,
  onReport,
  onBlock,
}: {
  profile: Profile;
  own: Profile | null;
  requests: ContactRequest[];
  contactDetails?: ContactDetails;
  onContact: (p: Profile) => void;
  onProposeSession: (p: Profile) => void;
  onReport: (p: Profile) => void;
  onBlock: (p: Profile) => void;
}) {
  const [menuOpen, setMenuOpen] = useState(false);
  const match = compatibilityScore(profile, own);
  const request = requests.find((item) =>
    (item.from_user === own?.id && item.to_user === profile.id) ||
    (item.to_user === own?.id && item.from_user === profile.id),
  );
  const initials = profile.firstName.slice(0, 2).toUpperCase();
  const displayedSubjects = profile.allSubjects
    ? ['Toutes les matières', ...profile.subjects]
    : profile.subjects;
  const isSharedSubject = (subject: string) => {
    if (!own) return false;
    if (profile.allSubjects) return own.allSubjects || own.subjects.length > 0;
    return own.allSubjects || own.subjects.includes(subject);
  };
  return <article className="profile-card" data-testid={`card-profile-${profile.id}`}>
    <div className="card-top"><div className={`profile-avatar avatar-${profile.id.length % 4}`} aria-hidden="true">{initials}</div><div className="profile-name-wrap"><h3 data-testid={`text-profile-name-${profile.id}`}>{profile.firstName}</h3><span className="profile-location"><MapPin size={14} />{profile.wilaya} · {profile.university}</span></div>
      {own && match.total > 0 && <span className="match-badge" data-testid={`badge-match-${profile.id}`}><Sparkles size={13} /> {match.total} point{match.total > 1 ? 's' : ''} commun{match.total > 1 ? 's' : ''}</span>}
      {own && <div className="card-menu-wrap">
        <button className="icon-button card-menu-trigger" type="button" aria-label={`Plus d’options pour ${profile.firstName}`} aria-expanded={menuOpen} onClick={() => setMenuOpen((open) => !open)} data-testid={`button-profile-menu-${profile.id}`}><MoreHorizontal size={18} /></button>
        {menuOpen && <div className="card-menu-popover menu-popover" role="menu" data-testid={`menu-profile-${profile.id}`}>
          <button className="menu-action" role="menuitem" type="button" onClick={() => { setMenuOpen(false); onReport(profile); }} data-testid={`button-report-${profile.id}`}><ShieldCheck size={16} />Signaler</button>
          <button className="menu-action menu-signout" role="menuitem" type="button" onClick={() => { setMenuOpen(false); onBlock(profile); }} data-testid={`button-block-${profile.id}`}><X size={16} />Bloquer</button>
        </div>}
      </div>}</div>
    <div className="profile-dates" data-testid={`text-profile-dates-${profile.id}`}>
      <time dateTime={profile.createdAt ?? undefined}>{profileDateLabel('Publié', profile.createdAt)}</time>
      <span>{profileDateLabel('Actif', profile.lastActiveAt)}</span>
    </div>
    <div className="profile-level"><GraduationCap size={16} /><span>{profile.level}{profile.studyType ? ` · ${profile.studyType}` : ''}</span></div>
    <div className="card-section"><div className="card-label"><BookOpen size={14} /> Matières à réviser</div><div className="chip-row">{displayedSubjects.map((s) => <span key={s} className={`subject-chip ${isSharedSubject(s) ? 'chip-match' : ''}`} data-testid={`tag-subject-${profile.id}-${s.toLowerCase().replaceAll(' ', '-')}`}>{s}</span>)}</div></div>
    <div className="card-section availability-section"><div className="card-label"><Clock3 size={14} /> Disponibilités</div><div className="chip-row">{profile.availability.map((t) => <span key={t} className={`time-chip ${own?.availability.includes(t) ? 'time-match' : ''}`} data-testid={`tag-time-${profile.id}-${t.toLowerCase().replaceAll(/[ .]/g, '-')}`}>{t}</span>)}</div></div>
    {profile.notes.trim() && <div className="profile-notes-section"><div className="card-label">À propos du binôme</div><p className="profile-notes" data-testid={`text-profile-notes-${profile.id}`}>{profile.notes}</p></div>}
    {own && match.total > 0 && <div className="compatibility-note" data-testid={`text-match-${profile.id}`}><CheckCircle2 size={14} />{match.subjects ? `${match.subjects} matière${match.subjects > 1 ? 's' : ''}` : ''}{match.subjects && match.times ? ' et ' : ''}{match.times ? `${match.times} créneau${match.times > 1 ? 'x' : ''}` : ''} en commun avec ton profil</div>}
    {!own ? <Link className="contact-button" href="/login" data-testid={`button-contact-${profile.id}`}>Se connecter pour contacter <ArrowRight size={16} /></Link> :
      request?.status === 'accepted' ? <div className="accepted-contact" data-testid={`contact-accepted-${profile.id}`}>
        <p className="contact-status"><CheckCircle2 size={15} />Accepté — coordonnées partagées</p>
        {contactDetails && <ContactLinks profileId={profile.id} details={contactDetails} />}
        {!contactDetails && <span className="contact-missing">Aucune coordonnée renseignée.</span>}
        <button className="button-primary button-small session-propose-button" type="button" onClick={() => onProposeSession(profile)} data-testid={`button-propose-session-${profile.id}`}>Proposer une session <CalendarDays size={15} /></button>
      </div> :
      request?.status === 'pending' && request.from_user === own.id ? <div className="contact-state pending-contact" role="status" data-testid={`contact-pending-${profile.id}`}><Clock3 size={15} />Demande envoyée</div> :
      request?.status === 'pending' ? <Link className="contact-button" href="/demandes" data-testid={`button-contact-${profile.id}`}>Demande reçue · Voir les demandes <ArrowRight size={16} /></Link> :
      request?.status === 'declined' ? <div className="contact-state declined-contact" role="status" data-testid={`contact-declined-${profile.id}`}>Refusé</div> :
      <button className="contact-button" onClick={() => onContact(profile)} data-testid={`button-contact-${profile.id}`}>Demander à contacter <ArrowRight size={16} /></button>}
  </article>;
}

function ContactLinks({ profileId, details }: { profileId: string; details: ContactDetails }) {
  const links: { key: ContactMethod; label: string; value: string; href: string; icon: ReactNode }[] = [];
  const telegram = details.telegram?.trim();
  const whatsapp = details.whatsapp?.trim();
  const email = details.contact_email?.trim();
  if (telegram) {
    const href = /^https?:\/\//i.test(telegram)
      ? telegram
      : `https://t.me/${encodeURIComponent(telegram.replace(/^@/, ''))}`;
    links.push({ key: 'telegram', label: 'Telegram', value: telegram, href, icon: <Send size={15} /> });
  }
  if (whatsapp) {
    const digits = whatsapp.replace(/[^\d]/g, '');
    const href = /^https?:\/\//i.test(whatsapp) ? whatsapp : `https://wa.me/${digits}`;
    links.push({ key: 'whatsapp', label: 'WhatsApp', value: whatsapp, href, icon: <Phone size={15} /> });
  }
  if (email) links.push({ key: 'contact_email', label: 'E-mail', value: email, href: `mailto:${email}`, icon: <Mail size={15} /> });
  if (!links.length) return <span className="contact-missing">Aucune coordonnée renseignée.</span>;
  return <div className="contact-links">{links.map((link) => <a
    key={link.key}
    className="contact-button contact-method-button"
    href={link.href}
    target={link.key === 'contact_email' ? undefined : '_blank'}
    rel={link.key === 'contact_email' ? undefined : 'noopener noreferrer'}
    data-testid={`link-contact-${link.key}-${profileId}`}
  >{link.icon}<span>{link.label}</span><ArrowRight size={15} /></a>)}</div>;
}

function hasContactDetails(details?: ContactDetails) {
  return Boolean(details?.telegram?.trim() || details?.whatsapp?.trim() || details?.contact_email?.trim());
}

function RequestsPage({
  userId,
  requests,
  profiles,
  contactDetails,
  blockedIds,
  loading,
  error,
  onUpdate,
  onCancel,
}: {
  userId: string;
  requests: ContactRequest[];
  profiles: Profile[];
  contactDetails: Record<string, ContactDetails>;
  blockedIds: string[];
  loading: boolean;
  error: string;
  onUpdate: (request: ContactRequest, status: 'accepted' | 'declined') => Promise<void>;
  onCancel: (request: ContactRequest) => Promise<void>;
}) {
  const [busyId, setBusyId] = useState('');
  const [actionError, setActionError] = useState('');
  const received = requests.filter((request) => request.to_user === userId && !blockedIds.includes(request.from_user));
  const sent = requests.filter((request) => request.from_user === userId && !blockedIds.includes(request.to_user));
  const runAction = async (request: ContactRequest, action: () => Promise<void>) => {
    setBusyId(request.id);
    setActionError('');
    try {
      await action();
    } catch (actionError) {
      setActionError(formatSupabaseError(actionError instanceof Error ? actionError : { message: String(actionError) }));
    } finally {
      setBusyId('');
    }
  };
  const renderRequest = (request: ContactRequest, direction: 'received' | 'sent') => {
    const partnerId = direction === 'received' ? request.from_user : request.to_user;
    const partner = profiles.find((profile) => profile.id === partnerId);
    const pending = request.status === 'pending';
    const label = request.status === 'accepted' ? 'Accepté' : request.status === 'declined' ? 'Refusé' : 'En attente';
    return <article className="request-card form-card" key={request.id} data-testid={`card-request-${request.id}`}>
      <div className="request-card-main">
        <span className={`request-avatar avatar-${partnerId.length % 4}`}>{partner?.firstName.slice(0, 2).toUpperCase() ?? 'ÉT'}</span>
        <div className="request-card-copy">
          <h3>{partner?.firstName ?? 'Étudiant'}</h3>
          <p>{partner?.wilaya ?? 'Profil indisponible'}{partner?.university ? ` · ${partner.university}` : ''}</p>
          {request.message?.trim() && <blockquote>{request.message}</blockquote>}
          <span className={`request-status status-${request.status}`}>{label}</span>
        </div>
      </div>
      {pending && direction === 'received' && <div className="request-actions">
        <button className="button-primary button-small" type="button" disabled={busyId === request.id} onClick={() => { void runAction(request, () => onUpdate(request, 'accepted')); }} data-testid={`button-accept-request-${request.id}`}>{busyId === request.id ? 'Traitement…' : 'Accepter'}</button>
        <button className="button-danger button-small" type="button" disabled={busyId === request.id} onClick={() => { void runAction(request, () => onUpdate(request, 'declined')); }} data-testid={`button-decline-request-${request.id}`}>Refuser</button>
      </div>}
      {pending && direction === 'sent' && <div className="request-actions">
        <button className="button-quiet button-small" type="button" disabled={busyId === request.id} onClick={() => { void runAction(request, () => onCancel(request)); }} data-testid={`button-cancel-request-${request.id}`}>{busyId === request.id ? 'Annulation…' : 'Annuler'}</button>
      </div>}
      {request.status === 'accepted' && hasContactDetails(contactDetails[partnerId]) && <div className="request-accepted-links" data-testid={`request-contacts-${request.id}`}>
        <ContactLinks profileId={partnerId} details={contactDetails[partnerId]} />
      </div>}
    </article>;
  };
  return <main className="browse-page relationship-page">
    <section className="page-heading">
      <div className="page-heading-inner"><div><div className="eyebrow"><span className="pulse-dot" /> TON ESPACE PERSONNEL</div><h1>Demandes de contact</h1><p>Accepte une demande pour partager tes coordonnées, ou refuse-la si tu préfères.</p></div><div className="profile-count"><strong>{received.filter((request) => request.status === 'pending').length}</strong><span>en attente<br />de réponse</span><Users size={20} /></div></div>
    </section>
    <section className="browse-content">
      {error && <div className="data-error" role="alert" data-testid="status-requests-error">{error}</div>}
      {actionError && <div className="data-error" role="alert" data-testid="status-request-action-error">{actionError}</div>}
      {loading ? <div className="loading-state" role="status">Chargement des demandes…</div> : error ? null : <>
        <div className="requests-section">
          <div className="browse-title-row"><div><h2>Reçues</h2><p>Les demandes envoyées par d’autres étudiants.</p></div><span className="result-count">{received.length}</span></div>
          {received.length ? <div className="request-list">{received.map((request) => renderRequest(request, 'received'))} </div> : <div className="empty-state request-empty"><div className="empty-icon"><Users size={24} /></div><h3>Aucune demande reçue</h3><p>Les nouvelles demandes apparaîtront ici.</p></div>}
        </div>
        <div className="requests-section">
          <div className="browse-title-row"><div><h2>Envoyées</h2><p>Les demandes que tu as faites.</p></div><span className="result-count">{sent.length}</span></div>
          {sent.length ? <div className="request-list">{sent.map((request) => renderRequest(request, 'sent'))}</div> : <div className="empty-state request-empty"><div className="empty-icon"><Send size={22} /></div><h3>Aucune demande envoyée</h3><p>Choisis « Demander à contacter » depuis un profil qui t’intéresse.</p></div>}
        </div>
      </>}
    </section>
  </main>;
}

function SessionsPage({
  userId,
  sessions,
  profiles,
  blockedIds,
  loading,
  error,
  onUpdate,
}: {
  userId: string;
  sessions: StudySession[];
  profiles: Profile[];
  blockedIds: string[];
  loading: boolean;
  error: string;
  onUpdate: (studySession: StudySession, status: StudySessionStatus) => Promise<void>;
}) {
  const [tab, setTab] = useState<'upcoming' | 'pending' | 'past'>('upcoming');
  const [busyId, setBusyId] = useState('');
  const [actionError, setActionError] = useState('');
  const now = Date.now();
  const visibleSessions = sessions.filter((item) => {
    const partnerId = item.requester === userId ? item.partner : item.requester;
    return !blockedIds.includes(partnerId);
  });
  const upcoming = visibleSessions.filter((item) => item.status === 'accepted' && new Date(item.starts_at).getTime() >= now);
  const pending = visibleSessions.filter((item) => item.status === 'proposed');
  const past = visibleSessions.filter((item) =>
    item.status === 'declined' || item.status === 'cancelled' ||
    (item.status === 'accepted' && new Date(item.starts_at).getTime() < now),
  );
  const tabSessions = { upcoming, pending, past }[tab];
  const tabLabels = [
    { key: 'upcoming' as const, label: 'À venir', items: upcoming },
    { key: 'pending' as const, label: 'En attente', items: pending },
    { key: 'past' as const, label: 'Passées', items: past },
  ];
  const runAction = async (studySession: StudySession, status: StudySessionStatus) => {
    setBusyId(studySession.id);
    setActionError('');
    try {
      await onUpdate(studySession, status);
    } catch (updateError) {
      setActionError(formatSupabaseError(updateError instanceof Error ? updateError : { message: String(updateError) }));
    } finally {
      setBusyId('');
    }
  };
  const renderSession = (studySession: StudySession) => {
    const isRequester = studySession.requester === userId;
    const partnerId = isRequester ? studySession.partner : studySession.requester;
    const partner = profiles.find((profile) => profile.id === partnerId);
    const statusLabel = studySession.status === 'proposed'
      ? 'En attente'
      : studySession.status === 'accepted'
        ? 'Acceptée'
        : studySession.status === 'declined'
          ? 'Refusée'
          : 'Annulée';
    const statusClass = studySession.status === 'proposed'
      ? 'status-pending'
      : studySession.status === 'accepted'
        ? 'status-accepted'
        : 'status-declined';
    return <article className="request-card form-card session-card" key={studySession.id} data-testid={`card-session-${studySession.id}`}>
      <div className="request-card-main">
        <span className={`request-avatar avatar-${partnerId.length % 4}`}>{partner?.firstName.slice(0, 2).toUpperCase() ?? 'ÉT'}</span>
        <div className="request-card-copy session-card-copy">
          <h3>{partner?.firstName ?? 'Étudiant'}</h3>
          <p className="session-datetime"><CalendarDays size={15} /><time dateTime={studySession.starts_at}>{formatAlgeriaSessionDate(studySession.starts_at)}</time></p>
          <p className="session-subject"><BookOpen size={15} />{studySession.subject}</p>
          {studySession.note?.trim() && <blockquote>{studySession.note}</blockquote>}
          <span className={`request-status ${statusClass}`}>{statusLabel}</span>
        </div>
      </div>
      <div className="request-actions session-actions">
        {studySession.status === 'proposed' && !isRequester && <>
          <button className="button-primary button-small" type="button" disabled={busyId === studySession.id} onClick={() => { void runAction(studySession, 'accepted'); }} data-testid={`button-accept-session-${studySession.id}`}>{busyId === studySession.id ? 'Traitement…' : 'Accepter'}</button>
          <button className="button-danger button-small" type="button" disabled={busyId === studySession.id} onClick={() => { void runAction(studySession, 'declined'); }} data-testid={`button-decline-session-${studySession.id}`}>Refuser</button>
        </>}
        {studySession.status === 'proposed' && isRequester && <button className="button-quiet button-small" type="button" disabled={busyId === studySession.id} onClick={() => { void runAction(studySession, 'cancelled'); }} data-testid={`button-cancel-session-${studySession.id}`}>{busyId === studySession.id ? 'Annulation…' : 'Annuler'}</button>}
        {studySession.status === 'accepted' && <button className="button-primary button-small" type="button" onClick={() => downloadSessionCalendar(studySession, partner?.firstName ?? 'mon binôme')} data-testid={`button-add-session-calendar-${studySession.id}`}><Download size={15} />Ajouter au calendrier</button>}
      </div>
    </article>;
  };
  return <main className="browse-page relationship-page sessions-page">
    <section className="page-heading">
      <div className="page-heading-inner"><div><div className="eyebrow"><span className="pulse-dot" /> TON ESPACE PERSONNEL</div><h1>Mes sessions</h1><p>Organise tes révisions et suis les propositions de tes binômes.</p></div><div className="profile-count"><strong>{upcoming.length}</strong><span>à venir</span><CalendarDays size={20} /></div></div>
    </section>
    <section className="browse-content">
      {error && <div className="data-error" role="alert" data-testid="status-sessions-error">{error}</div>}
      {actionError && <div className="data-error" role="alert" data-testid="status-session-action-error">{actionError}</div>}
      <div className="session-tabs" role="tablist" aria-label="Filtrer mes sessions">
        {tabLabels.map((item) => <button
          key={item.key}
          className={`button-quiet session-tab ${tab === item.key ? 'active' : ''}`}
          type="button"
          role="tab"
          aria-selected={tab === item.key}
          aria-controls="session-tab-panel"
          onClick={() => setTab(item.key)}
          data-testid={`tab-sessions-${item.key}`}
        >{item.label}<span className="session-tab-count">{item.items.length}</span></button>)}
      </div>
      <div id="session-tab-panel" className="session-tab-panel" role="tabpanel">
        {loading ? <div className="loading-state" role="status" data-testid="status-sessions-loading">Chargement des sessions…</div> :
          error ? null : tabSessions.length ? <div className="request-list">{tabSessions.map(renderSession)}</div> :
            <div className="empty-state request-empty" data-testid={`status-no-sessions-${tab}`}><div className="empty-icon"><CalendarDays size={24} /></div><h3>{tab === 'upcoming' ? 'Aucune session à venir' : tab === 'pending' ? 'Aucune proposition en attente' : 'Aucune session passée'}</h3><p>{tab === 'pending' ? 'Les propositions de tes binômes apparaîtront ici.' : 'Les sessions correspondantes apparaîtront ici.'}</p></div>}
      </div>
    </section>
  </main>;
}

function SessionDialog({
  profile,
  own,
  onClose,
  onSubmit,
}: {
  profile: Profile;
  own: Profile;
  onClose: () => void;
  onSubmit: (profile: Profile, date: string, time: string, subject: string, note: string) => Promise<void>;
}) {
  const subjectOptions = sharedSessionSubjects(own, profile);
  const [subject, setSubject] = useState(subjectOptions[0] ?? '');
  const [date, setDate] = useState('');
  const [time, setTime] = useState('');
  const [note, setNote] = useState('');
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');
  useEffect(() => {
    const close = (event: KeyboardEvent) => { if (event.key === 'Escape' && !busy) onClose(); };
    window.addEventListener('keydown', close);
    return () => window.removeEventListener('keydown', close);
  }, [busy, onClose]);
  const submit = async (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    setError('');
    if (!subjectOptions.length) {
      setError('Aucune matière en commun. Une personne doit choisir « Toutes les matières » pour proposer une session.');
      return;
    }
    if (!date || !time || !subject) {
      setError('Renseigne la date, l’heure et la matière.');
      return;
    }
    setBusy(true);
    try {
      await onSubmit(profile, date, time, subject, note);
    } catch (submitError) {
      setError(formatSupabaseError(submitError instanceof Error ? submitError : { message: String(submitError) }));
    } finally {
      setBusy(false);
    }
  };
  return <div className="dialog-overlay" role="presentation" onMouseDown={(event) => { if (event.target === event.currentTarget && !busy) onClose(); }} data-testid="dialog-session-overlay">
    <section className="contact-dialog session-dialog" role="dialog" aria-modal="true" aria-labelledby="session-dialog-title" data-testid="dialog-session">
      <button className="icon-button dialog-close" type="button" onClick={onClose} aria-label="Fermer" disabled={busy} data-testid="button-close-session"><X size={19} /></button>
      <div className="dialog-icon"><CalendarDays size={23} /></div>
      <div className="dialog-eyebrow">RÉVISIONS À DEUX</div>
      <h2 id="session-dialog-title">Proposer une session</h2>
      <p className="dialog-copy">Choisis un créneau en heure d’Algérie pour réviser avec {profile.firstName}.</p>
      <form className="relationship-dialog-form" onSubmit={(event) => { void submit(event); }} noValidate>
        <div className="session-form-grid">
          <label className="form-field"><span>Date <i>*</i></span><input type="date" value={date} min={algeriaDateKey()} onChange={(event) => setDate(event.target.value)} aria-label="Date de la session" data-testid="input-session-date" /></label>
          <label className="form-field"><span>Heure (Algérie) <i>*</i></span><input type="time" value={time} onChange={(event) => setTime(event.target.value)} aria-label="Heure de la session en Algérie" data-testid="input-session-time" /></label>
          <label className="form-field select-form-field session-subject-field"><span>Matière <i>*</i></span><select value={subject} onChange={(event) => setSubject(event.target.value)} disabled={!subjectOptions.length} aria-label="Matière de la session" data-testid="select-session-subject"><option value="">Choisir une matière</option>{subjectOptions.map((item) => <option key={item}>{item}</option>)}</select><ChevronDown size={17} /></label>
        </div>
        {!subjectOptions.length && <p className="session-no-subjects">Aucune matière en commun. Une personne doit choisir « Toutes les matières » pour proposer une session.</p>}
        <label className="form-field"><span>Note facultative</span><textarea value={note} onChange={(event) => setNote(event.target.value.slice(0, 200))} maxLength={200} rows={3} placeholder="Ajoute un détail pour ton binôme…" aria-label="Note facultative pour la session" data-testid="textarea-session-note" /></label>
        <span className="character-count" data-testid="text-session-note-count">{note.length}/200 caractères</span>
        {error && <div className="form-error dialog-error" role="alert" data-testid="status-session-dialog-error">{error}</div>}
        <div className="dialog-actions">
          <button className="button-primary button-small" type="submit" disabled={busy || !subjectOptions.length} data-testid="button-submit-session">{busy ? 'Envoi…' : 'Envoyer la proposition'} <ArrowRight size={16} /></button>
          <button className="button-light button-small" type="button" onClick={onClose} disabled={busy} data-testid="button-cancel-session">Annuler</button>
        </div>
      </form>
      <div className="dialog-footnote"><ShieldCheck size={15} />Les horaires sont affichés en heure d’Algérie (Africa/Algiers).</div>
    </section>
  </div>;
}

function ProfileForm({
  own,
  ownContacts,
  ownContactsError,
  blockedIds,
  blockedProfiles,
  loading,
  onSubmit,
  onDeleteProfile,
  onDeleteAccount,
  onUnblock,
  onSignOut,
}: {
  own: Profile | null;
  ownContacts: ContactDetails;
  ownContactsError: string;
  blockedIds: string[];
  blockedProfiles: Profile[];
  loading: boolean;
  onSubmit: (profile: ProfileInput) => Promise<void>;
  onDeleteProfile: () => Promise<void>;
  onDeleteAccount: () => Promise<void>;
  onUnblock: (id: string) => Promise<void>;
  onSignOut: () => Promise<void>;
}) {
  const [, setLocation] = useLocation();
  const [firstName, setFirstName] = useState(own?.firstName || '');
  const [wilaya, setWilaya] = useState(own?.wilaya || '');
  const [university, setUniversity] = useState(own?.university || '');
  const [pickedSubjects, setPickedSubjects] = useState<string[]>(own?.subjects || []);
  const [gender, setGender] = useState<'male' | 'female' | ''>(own?.gender ?? '');
  const [otherOpen, setOtherOpen] = useState(false);
  const [otherName, setOtherName] = useState('');
  const [otherError, setOtherError] = useState('');
  const [allSubjects, setAllSubjects] = useState(own?.allSubjects ?? false);
  const [level, setLevel] = useState(own?.level || '');
  const [studyType, setStudyType] = useState(own?.studyType || '');
  const [availability, setAvailability] = useState<string[]>(own?.availability || []);
  const [notes, setNotes] = useState(own?.notes || '');
  const [telegram, setTelegram] = useState(ownContacts.telegram ?? '');
  const [whatsapp, setWhatsapp] = useState(ownContacts.whatsapp ?? '');
  const [contactEmail, setContactEmail] = useState(ownContacts.contact_email ?? '');
  const [validationAttempted, setValidationAttempted] = useState(false);
  const [saveError, setSaveError] = useState('');
  const [submitting, setSubmitting] = useState(false);
  const [confirmDelete, setConfirmDelete] = useState<'profile' | 'account' | null>(null);
  const [unblockError, setUnblockError] = useState('');
  const [unblockingId, setUnblockingId] = useState('');

  useEffect(() => {
    setTelegram(ownContacts.telegram ?? '');
    setWhatsapp(ownContacts.whatsapp ?? '');
    setContactEmail(ownContacts.contact_email ?? '');
  }, [ownContacts.telegram, ownContacts.whatsapp, ownContacts.contact_email]);
  const validationMessages: string[] = [];
  if (!firstName.trim()) validationMessages.push('Renseigne ton prénom.');
  if (!wilaya) validationMessages.push('Choisis ta wilaya.');
  if (!university) validationMessages.push('Choisis ton université.');
  const pendingOtherName = otherOpen ? (findListedSubject(normalizeSubjectName(otherName)) ?? normalizeSubjectName(otherName)) : '';
  const effectiveSubjects = pendingOtherName && !pickedSubjects.some((item) => subjectKey(item) === subjectKey(pendingOtherName)) ? [...pickedSubjects, pendingOtherName] : pickedSubjects;
  if (!allSubjects && effectiveSubjects.length === 0) validationMessages.push('Choisis au moins une matière.');
  if (otherOpen && !otherName.trim() && !pickedSubjects.some((item) => !isListedSubject(item))) validationMessages.push('Écris le nom de la matière « Autre » ou décoche-la.');
  if (!level || level === 'Niveau non renseigné') validationMessages.push('Choisis ton niveau de préparation.');
  if (!studyType) validationMessages.push('Choisis ton mode de révision.');
  if (!gender) validationMessages.push('Choisis ton sexe.');
  if (availability.length === 0) validationMessages.push('Choisis au moins un créneau de disponibilité.');
  if (notes.length > 300) validationMessages.push('Raccourcis ta note à 300 caractères maximum.');
  const confirmDeleteAction = async () => {
    if (confirmDelete === 'account') {
      await onDeleteAccount();
      setLocation('/login');
    } else {
      await onDeleteProfile();
    }
  };
  const toggle = (list: string[], value: string, update: (a: string[]) => void) => update(list.includes(value) ? list.filter((item) => item !== value) : [...list, value]);
  const addOtherSubject = () => {
    const name = normalizeSubjectName(otherName);
    if (!name) { setOtherError('Écris le nom de la matière.'); return; }
    const finalName = findListedSubject(name) ?? pickedSubjects.find((item) => subjectKey(item) === subjectKey(name)) ?? name;
    setAllSubjects(false);
    setPickedSubjects((current) => current.some((item) => subjectKey(item) === subjectKey(finalName)) ? current : [...current, finalName]);
    setOtherName('');
    setOtherError('');
  };
  const savedSubjectsNotInList = pickedSubjects.filter((saved) => !subjects.some((known) => known === saved));
  const savedAvailabilityNotInList = availability.filter((slot) => !slots.includes(slot));
  const knownLevels = ['Début de préparation', 'Rythme régulier', 'Révisions avancées'];
  const handleSubmit = async (e: FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    setSaveError('');
    setValidationAttempted(true);
    if (validationMessages.length > 0) {
      document.getElementById('profile-submit-area')?.scrollIntoView({ behavior: 'smooth', block: 'center' });
      return;
    }
    setValidationAttempted(false);
    setSaveError('');
    setSubmitting(true);
    try {
      await onSubmit({
        firstName: firstName.trim(),
        wilaya,
        university,
        subjects: effectiveSubjects,
        allSubjects,
        level,
        studyType,
        availability,
        notes,
        telegram,
        whatsapp,
        contactEmail,
        gender,
      });
      setLocation('/profils');
    } catch (submitError) {
      setSaveError(formatSupabaseError(submitError instanceof Error ? submitError : { message: String(submitError) }));
    } finally {
      setSubmitting(false);
    }
  };
  return <main className="form-page">
    <section className="form-heading"><div className="form-heading-inner"><div className="eyebrow"><span className="pulse-dot" /> TON PARCOURS, TON RYTHME</div><h1>{own ? 'Ton profil, à jour.' : 'Fais le premier pas.'}</h1><p>Quelques infos suffisent pour trouver des étudiants qui te ressemblent.</p><div className="form-progress"><span className="progress-active"></span><span></span><span></span><span></span><span></span><small>ENVIRON 1 MINUTE</small></div></div></section>
    <section className="form-content">
      {loading ? <LoadingPage /> : <form onSubmit={handleSubmit} noValidate data-testid="form-create-profile">
        <div className="form-card">
          <div className="form-section-head"><span className="form-step">01</span><div><h2>Un peu sur toi</h2><p>Pour que ton binôme sache à qui il a affaire.</p></div></div>
          <div className="form-two-col">
            <label className="form-field"><span>Ton prénom <i>*</i></span><input value={firstName} onChange={(e) => setFirstName(e.target.value)} placeholder="Ex. Amel" maxLength={40} required aria-invalid={validationAttempted && !firstName.trim()} aria-label="Ton prénom" data-testid="input-first-name" /></label>
            <label className="form-field select-form-field"><span>Ta wilaya <i>*</i></span><select value={wilaya} onChange={(e) => setWilaya(e.target.value)} required aria-invalid={validationAttempted && !wilaya} aria-label="Ta wilaya" data-testid="select-wilaya"><option value="">Choisir une wilaya</option>{wilaya && !wilayas.some((item) => item === wilaya) && <option value={wilaya}>{wilaya} · enregistrée</option>}{wilayas.map((w) => <option key={w}>{w}</option>)}</select><ChevronDown size={17} /></label>
            <label className="form-field select-form-field"><span>Ton université <i>*</i></span><select value={university} onChange={(e) => setUniversity(e.target.value)} required aria-invalid={validationAttempted && !university} aria-label="Ton université" data-testid="select-university"><option value="">Choisir une université</option>{university && !UNIVERSITIES.some((item) => item === university) && <option value={university}>{university} · enregistrée</option>}{UNIVERSITIES.map((item) => <option key={item}>{item}</option>)}</select><ChevronDown size={17} /></label>
            <label className="form-field select-form-field"><span>Mode de révision <i>*</i></span><select value={studyType} onChange={(e) => setStudyType(e.target.value)} required aria-invalid={validationAttempted && !studyType} aria-label="Mode de révision" data-testid="select-study-type"><option value="">Choisir un mode</option>{studyType && !STUDY_TYPES.some((item) => item === studyType) && <option value={studyType}>{studyType} · enregistré</option>}{STUDY_TYPES.map((item) => <option key={item}>{item}</option>)}</select><ChevronDown size={17} /></label>
            <label className="form-field select-form-field"><span>Sexe <i>*</i></span><select value={gender} onChange={(e) => setGender(e.target.value as 'male' | 'female' | '')} required aria-invalid={validationAttempted && !gender} aria-label="Sexe" data-testid="select-gender"><option value="">Choisir</option><option value="male">Masculin</option><option value="female">Féminin</option></select><ChevronDown size={17} /></label>
          </div>
        </div>
        <div className="form-card">
          <div className="form-section-head"><span className="form-step">02</span><div><h2>Ce que tu révises</h2><p>Choisis toutes les matières que tu veux travailler.</p></div><span className="selection-count" data-testid="text-subject-count">{allSubjects ? 'Toutes les matières' : `${pickedSubjects.length} sélectionnée${pickedSubjects.length !== 1 ? 's' : ''}`}</span></div>
          <div className="subject-picker" role="group" aria-invalid={validationAttempted && !allSubjects && pickedSubjects.length === 0} aria-label="Matières à réviser">
            <button
              type="button"
              className={`picker-chip ${allSubjects ? 'selected' : ''}`}
              onClick={() => {
                const next = !allSubjects;
                setAllSubjects(next);
                if (next) setPickedSubjects([]);
              }}
              aria-pressed={allSubjects}
              data-testid="button-subject-all"
            >{allSubjects && <Check size={14} />}Toutes les matières</button>
            {subjects.map((s) => {
              const selected = pickedSubjects.includes(s);
              return <button
                type="button"
                className={`picker-chip ${selected ? 'selected' : ''}`}
                key={s}
                onClick={() => {
                  setAllSubjects(false);
                  toggle(pickedSubjects, s, setPickedSubjects);
                }}
                aria-pressed={selected}
                data-testid={`button-subject-${s.toLowerCase().replaceAll(' ', '-')}`}
              >{selected && <Check size={14} />}{s}</button>;
            })}
            {savedSubjectsNotInList.map((saved) => <button
              type="button"
              className="picker-chip selected saved-subject-chip"
              key={saved}
              onClick={() => {
                setAllSubjects(false);
                toggle(pickedSubjects, saved, setPickedSubjects);
              }}
              aria-pressed="true"
              aria-label={`Retirer la matière enregistrée ${saved}`}
              data-testid={`button-subject-saved-${saved.toLowerCase().replaceAll(' ', '-')}`}
            ><Check size={14} />{saved}</button>)}
            <button
              type="button"
              className={`picker-chip ${otherOpen ? 'selected' : ''}`}
              onClick={() => { const next = !otherOpen; setOtherOpen(next); setOtherError(''); if (next) setAllSubjects(false); }}
              aria-pressed={otherOpen}
              data-testid="button-subject-other"
            >{otherOpen && <Check size={14} />}Autre</button>
          </div>
          {otherOpen && <div className="other-subject-box">
            <label className="form-field"><span>Nom de la matière <i>*</i></span>
              <input value={otherName} maxLength={40} onChange={(e) => { setOtherName(e.target.value); setOtherError(''); }} onKeyDown={(e) => { if (e.key === 'Enter') { e.preventDefault(); addOtherSubject(); } }} placeholder="Ex. Médecine légale" aria-label="Nom de la matière" aria-invalid={Boolean(otherError)} data-testid="input-other-subject" />
            </label>
            <button type="button" className="button-light button-small" onClick={addOtherSubject} data-testid="button-add-other-subject">Ajouter</button>
            {otherError && <p className="form-error" role="alert" data-testid="status-other-subject-error">{otherError}</p>}
          </div>}
        </div>
        <div className="form-card">
          <div className="form-section-head"><span className="form-step">03</span><div><h2>Ton rythme de préparation</h2><p>Il n’y a pas de bonne réponse — seulement ton rythme.</p></div></div>
          <div className="level-options" role="radiogroup" aria-invalid={validationAttempted && (!level || level === 'Niveau non renseigné')} aria-label="Niveau de préparation">
            {[['Début de préparation', 'Je pose mes bases et organise mes révisions.'], ['Rythme régulier', 'J’ai commencé et je garde le cap semaine après semaine.'], ['Révisions avancées', 'Je consolide et je prépare les dernières lignes droites.']].map(([name, desc], i) => <button type="button" key={name} role="radio" aria-checked={level === name} onClick={() => setLevel(name)} className={`level-option ${level === name ? 'chosen' : ''}`} data-testid={`button-level-${i + 1}`}><span className="radio-mark">{level === name && <span />}</span><span><strong>{name}</strong><small>{desc}</small></span><ArrowRight size={16} /></button>)}
            {level && level !== 'Niveau non renseigné' && !knownLevels.includes(level) && <button type="button" role="radio" aria-checked="true" onClick={() => setLevel('')} className="level-option chosen saved-level-option" data-testid="button-level-saved"><span className="radio-mark"><span /></span><span><strong>{level}</strong><small>Niveau enregistré dans ton profil · touche pour retirer</small></span><ArrowRight size={16} /></button>}
          </div>
        </div>
        <div className="form-card">
          <div className="form-section-head"><span className="form-step">04</span><div><h2>Quand tu es disponible</h2><p>Choisis tes créneaux, même s’ils changent d’une semaine à l’autre.</p></div><span className="selection-count" data-testid="text-availability-count">{availability.length} créneau{availability.length !== 1 ? 'x' : ''}</span></div>
          <div className="availability-picker" role="group" aria-invalid={validationAttempted && availability.length === 0} aria-label="Disponibilités">{['Lun.', 'Mar.', 'Mer.', 'Jeu.', 'Ven.', 'Sam.', 'Dim.'].map((day) => <div className="day-row" key={day}><span className="day-label">{day}</span><div className="day-slots">{['matin', 'soir'].map((period) => { const key = `${day} ${period}`; return <button type="button" className={`slot-button ${availability.includes(key) ? 'selected' : ''}`} onClick={() => toggle(availability, key, setAvailability)} aria-pressed={availability.includes(key)} key={key} data-testid={`button-slot-${day.toLowerCase()}-${period}`}>{period === 'matin' ? 'Matin' : 'Soir'}</button>; })}</div></div>)}</div>
          {savedAvailabilityNotInList.length > 0 && <div className="saved-availability"><span>Autres créneaux enregistrés</span><div>{savedAvailabilityNotInList.map((slot) => <button key={slot} type="button" className="slot-button selected saved-slot-button" onClick={() => toggle(availability, slot, setAvailability)} aria-pressed="true">{slot} <X size={13} /></button>)}</div></div>}
          <p className="availability-help"><CalendarDays size={15} /> Les créneaux sont indicatifs et modifiables à tout moment.</p>
        </div>
        <div className="form-card">
          <div className="form-section-head"><span className="form-step">05</span><div><h2>Ce que tu recherches</h2><p>Ajoute quelques précisions pour aider ton futur binôme.</p></div></div>
          <label className="form-field notes-field">
            <span>Que cherches-tu exactement ?</span>
            <textarea value={notes} onChange={(event) => setNotes(event.target.value)} maxLength={300} rows={4} aria-invalid={validationAttempted && notes.length > 300} placeholder="Ex. Un binôme régulier pour revoir la cardiologie et se motiver avant les examens." aria-label="Que cherches-tu exactement ?" data-testid="textarea-profile-notes" />
            <span className="character-count" aria-live="polite" data-testid="text-notes-count">{notes.length}/300 caractères</span>
          </label>
        </div>
        <div className="form-card">
          <div className="form-section-head"><span className="form-step">06</span><div><h2>Tes coordonnées privées</h2><p>Elles ne sont visibles qu’après acceptation de ta demande de contact.</p></div></div>
          {ownContactsError && <div className="form-save-error contact-load-warning" role="alert" data-testid="status-private-contacts-error">Tes coordonnées actuelles n’ont pas pu être chargées. Elles ne seront pas écrasées. Vérifie ton accès Supabase avant de les modifier.<br />{ownContactsError}</div>}
          <div className="form-two-col contact-form-grid">
            <label className="form-field"><span>Telegram</span><input value={telegram} onChange={(event) => setTelegram(event.target.value)} maxLength={120} autoComplete="off" placeholder="@nom_utilisateur" aria-label="Ton identifiant Telegram" disabled={Boolean(ownContactsError)} data-testid="input-contact-telegram" /></label>
            <label className="form-field"><span>WhatsApp</span><input value={whatsapp} onChange={(event) => setWhatsapp(event.target.value)} maxLength={40} autoComplete="tel" placeholder="+213…" aria-label="Ton numéro WhatsApp" disabled={Boolean(ownContactsError)} data-testid="input-contact-whatsapp" /></label>
            <label className="form-field contact-email-field"><span>E-mail</span><input type="email" value={contactEmail} onChange={(event) => setContactEmail(event.target.value)} maxLength={254} autoComplete="email" placeholder="nom@exemple.com" aria-label="Ton e-mail de contact" disabled={Boolean(ownContactsError)} data-testid="input-contact-email" /></label>
          </div>
        </div>
        <div className="form-submit-area" id="profile-submit-area">
          {validationAttempted && validationMessages.length > 0 && <div className="form-error" id="profile-error" role="alert" aria-live="polite" data-testid="status-form-error"><X size={17} />{validationMessages[0]}</div>}
          {saveError && <div className="form-save-error" role="alert" data-testid="status-profile-save-error">{saveError}</div>}
          <div className="privacy-reminder"><ShieldCheck size={18} /><span>Ton profil est enregistré dans Supabase.<br />Tes coordonnées ne sont pas affichées sur cette page.</span></div>
          <button className="button-primary submit-profile" type="submit" disabled={submitting} data-testid="button-submit-profile">{submitting ? 'Enregistrement…' : own ? 'Enregistrer les modifications' : 'Créer mon profil'} <ArrowRight size={18} /></button>
          {own && <p className="already-profile" data-testid="text-profile-exists"><CheckCircle2 size={15} /> Ton profil est déjà visible dans la liste des binômes.</p>}
        </div>
      </form>}
      <section className="account-actions form-card" aria-labelledby="account-actions-title">
        <div className="form-section-head"><span className="form-step"><ShieldCheck size={15} /></span><div><h2 id="account-actions-title">Compte et profil</h2><p>Ces deux suppressions sont indépendantes.</p></div></div>
        <div className="account-actions-row">
          {own && <button className="button-danger button-small" type="button" onClick={() => setConfirmDelete('profile')} data-testid="button-delete-profile">Supprimer mon profil</button>}
          <button className="button-danger button-small" type="button" onClick={() => setConfirmDelete('account')} data-testid="button-delete-account">Supprimer mon compte</button>
          <button className="button-quiet button-small" type="button" onClick={() => { void onSignOut(); }} data-testid="button-profile-sign-out">Se déconnecter</button>
        </div>
      </section>
      <section className="blocked-users-section form-card" aria-labelledby="blocked-users-title">
        <div className="form-section-head"><span className="form-step"><ShieldCheck size={15} /></span><div><h2 id="blocked-users-title">Utilisateurs bloqués</h2><p>Les profils bloqués ne sont plus visibles dans la recherche.</p></div><span className="selection-count">{blockedIds.length}</span></div>
        {unblockError && <div className="form-save-error" role="alert" data-testid="status-unblock-error">{unblockError}</div>}
        {blockedIds.length === 0 ? <p className="blocked-empty">Tu n’as bloqué aucun utilisateur.</p> :
          <ul className="blocked-users-list">{blockedIds.map((id) => {
            const profile = blockedProfiles.find((item) => item.id === id);
            return <li key={id} className="blocked-user-row"><span><strong>{profile?.firstName ?? 'Étudiant'}</strong><small>{profile?.wilaya ?? 'Profil indisponible'}</small></span><button className="button-quiet button-small" type="button" disabled={unblockingId === id} onClick={() => {
              setUnblockingId(id);
              setUnblockError('');
              void onUnblock(id).catch((error: unknown) => setUnblockError(formatSupabaseError(error instanceof Error ? error : { message: String(error) }))).finally(() => setUnblockingId(''));
            }} data-testid={`button-unblock-${id}`}>{unblockingId === id ? 'Déblocage…' : 'Débloquer'}</button></li>;
          })}</ul>}
      </section>
    </section>
    {confirmDelete && <ConfirmDialog
      kind={confirmDelete}
      onClose={() => setConfirmDelete(null)}
      onConfirm={confirmDeleteAction}
    />}
  </main>;
}

function LoadingPage() {
  return <main className="auth-page"><div className="loading-state" role="status" data-testid="status-auth-loading">Chargement de ton espace…</div></main>;
}

function SignedInPage({ onSignOut }: { onSignOut: () => Promise<void> }) {
  return <main className="auth-page">
    <section className="auth-card form-card" aria-labelledby="signed-in-title">
      <div className="auth-mark"><CheckCircle2 size={24} /></div>
      <div className="eyebrow"><span className="pulse-dot" /> SESSION ACTIVE</div>
      <h1 id="signed-in-title">Tu es déjà connecté.</h1>
      <p className="auth-copy">Ton espace Binôme est prêt. Tu peux consulter ton profil ou fermer ta session.</p>
      <div className="auth-signed-actions">
        <Link className="button-primary" href="/mon-profil" data-testid="link-signed-in-profile">Ouvrir mon profil <ArrowRight size={17} /></Link>
        <button className="button-quiet" type="button" onClick={() => { void onSignOut(); }} data-testid="button-signed-in-sign-out">Se déconnecter <LogOut size={16} /></button>
      </div>
    </section>
  </main>;
}

function ConfirmDialog({
  kind,
  onClose,
  onConfirm,
}: {
  kind: 'profile' | 'account';
  onClose: () => void;
  onConfirm: () => Promise<void>;
}) {
  const [phrase, setPhrase] = useState('');
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');
  const account = kind === 'account';
  const confirm = async () => {
    setBusy(true);
    setError('');
    try {
      await onConfirm();
      onClose();
    } catch (confirmError) {
      setError(formatSupabaseError(confirmError instanceof Error ? confirmError : { message: String(confirmError) }));
    } finally {
      setBusy(false);
    }
  };

  useEffect(() => {
    const close = (event: KeyboardEvent) => {
      if (event.key === 'Escape' && !busy) onClose();
    };
    window.addEventListener('keydown', close);
    return () => window.removeEventListener('keydown', close);
  }, [busy, onClose]);

  return <div className="dialog-overlay" role="presentation" onMouseDown={(event) => { if (event.target === event.currentTarget && !busy) onClose(); }} data-testid={`dialog-delete-${kind}-overlay`}>
    <section className="contact-dialog confirm-dialog" role="alertdialog" aria-modal="true" aria-labelledby={`delete-${kind}-title`} data-testid={`dialog-delete-${kind}`}>
      <button className="icon-button dialog-close" type="button" onClick={onClose} aria-label="Fermer" disabled={busy} data-testid={`button-close-delete-${kind}`}><X size={19} /></button>
      <div className="dialog-icon danger-icon"><ShieldCheck size={23} /></div>
      <div className="dialog-eyebrow">ACTION IRRÉVERSIBLE</div>
      <h2 id={`delete-${kind}-title`}>{account ? 'Supprimer ton compte ?' : 'Supprimer ton profil ?'}</h2>
      <p className="dialog-copy">{account
        ? 'Ton compte sera supprimé avec la fonction sécurisée prévue dans Supabase, puis tu seras déconnecté. Cette action est définitive.'
        : 'Seule ta fiche de profil sera supprimée. Ton compte restera actif et tu pourras créer un nouveau profil plus tard.'}</p>
      {account && <label className="form-field delete-confirm-field"><span>Écris SUPPRIMER pour confirmer</span><input value={phrase} onChange={(event) => setPhrase(event.target.value)} autoComplete="off" aria-label="Écris SUPPRIMER pour confirmer" data-testid="input-delete-confirmation" /></label>}
      {error && <div className="form-error delete-error" role="alert" data-testid={`status-delete-${kind}-error`}>{error}</div>}
      <div className="dialog-actions">
        <button className="button-danger button-small" type="button" onClick={() => { void confirm(); }} disabled={busy || (account && phrase !== 'SUPPRIMER')} data-testid={`button-confirm-delete-${kind}`}>{busy ? 'Suppression…' : account ? 'Supprimer mon compte' : 'Supprimer mon profil'}</button>
        <button className="button-light button-small" type="button" onClick={onClose} disabled={busy} data-testid={`button-cancel-delete-${kind}`}>Annuler</button>
      </div>
    </section>
  </div>;
}

function ContactDialog({
  profile,
  onClose,
  onSubmit,
}: {
  profile: Profile;
  onClose: () => void;
  onSubmit: (profile: Profile, message: string) => Promise<void>;
}) {
  const [message, setMessage] = useState('');
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');
  useEffect(() => {
    const close = (e: KeyboardEvent) => { if (e.key === 'Escape' && !busy) onClose(); };
    window.addEventListener('keydown', close);
    return () => window.removeEventListener('keydown', close);
  }, [busy, onClose]);
  const submit = async (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    setBusy(true);
    setError('');
    try {
      await onSubmit(profile, message);
    } catch (submitError) {
      setError(formatSupabaseError(submitError instanceof Error ? submitError : { message: String(submitError) }));
    } finally {
      setBusy(false);
    }
  };
  return <div className="dialog-overlay" role="presentation" onMouseDown={(e) => { if (e.target === e.currentTarget && !busy) onClose(); }} data-testid="dialog-contact-overlay">
    <section className="contact-dialog" role="dialog" aria-modal="true" aria-labelledby="contact-title" data-testid="dialog-contact">
      <button className="icon-button dialog-close" type="button" onClick={onClose} aria-label="Fermer" disabled={busy} data-testid="button-close-contact"><X size={19} /></button>
      <div className="dialog-icon"><BookOpen size={24} /></div>
      <div className="dialog-eyebrow">DEMANDE DE CONTACT</div>
      <h2 id="contact-title">Contacter {profile.firstName} ?</h2>
      <p className="dialog-copy">Envoie une demande pour pouvoir échanger. Tes coordonnées ne seront partagées qu’après acceptation.</p>
      <div className="dialog-summary"><span className="dialog-initials">{profile.firstName.slice(0, 2).toUpperCase()}</span><div><strong>{profile.firstName}</strong><span><MapPin size={13} />{profile.wilaya}</span></div><ShieldCheck size={18} /></div>
      <form className="relationship-dialog-form" onSubmit={(event) => { void submit(event); }}>
        <label className="form-field"><span>Message facultatif</span><textarea value={message} onChange={(event) => setMessage(event.target.value.slice(0, 200))} maxLength={200} rows={4} placeholder="Présente-toi et explique ce que tu aimerais réviser ensemble…" aria-label="Message facultatif" data-testid="textarea-contact-request-message" /></label>
        <span className="character-count" data-testid="text-contact-message-count">{message.length}/200 caractères</span>
        {error && <div className="form-error dialog-error" role="alert" data-testid="status-contact-error">{error}</div>}
        <div className="dialog-actions">
          <button className="button-primary button-small" type="submit" disabled={busy} data-testid="button-submit-contact-request">{busy ? 'Envoi…' : 'Envoyer la demande'} <ArrowRight size={16} /></button>
          <button className="button-light button-small" type="button" onClick={onClose} disabled={busy} data-testid="button-cancel-contact">Annuler</button>
        </div>
      </form>
      <div className="dialog-footnote"><ShieldCheck size={15} />Les coordonnées restent privées tant que la demande n’est pas acceptée.</div>
    </section>
  </div>;
}

function ReportDialog({
  profile,
  onClose,
  onSubmit,
}: {
  profile: Profile;
  onClose: () => void;
  onSubmit: (profile: Profile, reason: ReportReason, details: string) => Promise<void>;
}) {
  const [reason, setReason] = useState<ReportReason | ''>('');
  const [details, setDetails] = useState('');
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');
  useEffect(() => {
    const close = (event: KeyboardEvent) => { if (event.key === 'Escape' && !busy) onClose(); };
    window.addEventListener('keydown', close);
    return () => window.removeEventListener('keydown', close);
  }, [busy, onClose]);
  const submit = async (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    if (!reason) return;
    setBusy(true);
    setError('');
    try {
      await onSubmit(profile, reason, details);
    } catch (submitError) {
      setError(formatSupabaseError(submitError instanceof Error ? submitError : { message: String(submitError) }));
    } finally {
      setBusy(false);
    }
  };
  return <div className="dialog-overlay" role="presentation" onMouseDown={(event) => { if (event.target === event.currentTarget && !busy) onClose(); }} data-testid="dialog-report-overlay">
    <section className="contact-dialog" role="dialog" aria-modal="true" aria-labelledby="report-title" data-testid="dialog-report">
      <button className="icon-button dialog-close" type="button" onClick={onClose} aria-label="Fermer" disabled={busy}><X size={19} /></button>
      <div className="dialog-icon"><ShieldCheck size={23} /></div>
      <div className="dialog-eyebrow">SIGNALEMENT CONFIDENTIEL</div>
      <h2 id="report-title">Signaler {profile.firstName}</h2>
      <p className="dialog-copy">Choisis la raison du signalement et ajoute des précisions si nécessaire.</p>
      <form className="relationship-dialog-form" onSubmit={(event) => { void submit(event); }}>
        <label className="form-field select-form-field"><span>Motif <i>*</i></span><select value={reason} onChange={(event) => setReason(event.target.value as ReportReason | '')} required aria-label="Motif du signalement" data-testid="select-report-reason"><option value="">Choisir un motif</option><option value="spam">Spam</option><option value="harcelement">Harcèlement</option><option value="faux_profil">Faux profil</option><option value="autre">Autre</option></select><ChevronDown size={17} /></label>
        <label className="form-field"><span>Précisions facultatives</span><textarea value={details} onChange={(event) => setDetails(event.target.value.slice(0, 300))} maxLength={300} rows={4} placeholder="Décris brièvement la situation…" aria-label="Précisions sur le signalement" data-testid="textarea-report-details" /></label>
        <span className="character-count" data-testid="text-report-details-count">{details.length}/300 caractères</span>
        {error && <div className="form-error dialog-error" role="alert">{error}</div>}
        <div className="dialog-actions">
          <button className="button-danger button-small" type="submit" disabled={busy || !reason} data-testid="button-submit-report">{busy ? 'Envoi…' : 'Envoyer le signalement'}</button>
          <button className="button-light button-small" type="button" onClick={onClose} disabled={busy}>Annuler</button>
        </div>
      </form>
    </section>
  </div>;
}

function BlockDialog({ profile, onClose, onConfirm }: { profile: Profile; onClose: () => void; onConfirm: () => Promise<void> }) {
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');
  useEffect(() => {
    const close = (event: KeyboardEvent) => { if (event.key === 'Escape' && !busy) onClose(); };
    window.addEventListener('keydown', close);
    return () => window.removeEventListener('keydown', close);
  }, [busy, onClose]);
  const confirm = async () => {
    setBusy(true);
    setError('');
    try {
      await onConfirm();
      onClose();
    } catch (confirmError) {
      setError(formatSupabaseError(confirmError instanceof Error ? confirmError : { message: String(confirmError) }));
    } finally {
      setBusy(false);
    }
  };
  return <div className="dialog-overlay" role="presentation" onMouseDown={(event) => { if (event.target === event.currentTarget && !busy) onClose(); }} data-testid="dialog-block-overlay">
    <section className="contact-dialog confirm-dialog" role="alertdialog" aria-modal="true" aria-labelledby="block-title" data-testid="dialog-block">
      <button className="icon-button dialog-close" type="button" onClick={onClose} aria-label="Fermer" disabled={busy}><X size={19} /></button>
      <div className="dialog-icon danger-icon"><ShieldCheck size={23} /></div>
      <div className="dialog-eyebrow">PROTECTION DE TON ESPACE</div>
      <h2 id="block-title">Bloquer {profile.firstName} ?</h2>
      <p className="dialog-copy">Ce profil ne sera plus visible pour toi. Les demandes de contact entre vous seront masquées. Tu pourras débloquer cette personne depuis « Mon profil ».</p>
      {error && <div className="form-error dialog-error" role="alert">{error}</div>}
      <div className="dialog-actions">
        <button className="button-danger button-small" type="button" onClick={() => { void confirm(); }} disabled={busy} data-testid="button-confirm-block">{busy ? 'Blocage…' : 'Bloquer cet utilisateur'}</button>
        <button className="button-light button-small" type="button" onClick={onClose} disabled={busy}>Annuler</button>
      </div>
    </section>
  </div>;
}

function Footer() {
  return <footer className="site-footer"><div className="footer-inner"><Link href="/" className="brand footer-brand" data-testid="link-footer-home"><span className="brand-mark"><BookOpen size={17} /></span><span className="brand-name">Binôme</span></Link><p>Réviser ensemble, avancer autrement.</p><span className="footer-note">Étudiants en médecine · Algérie</span></div></footer>;
}

function MissingRoute() {
  return <main className="missing-route"><div className="missing-mark">404</div><h1>Cette page n’existe pas.</h1><p>Retrouve les profils de révision ou reviens à l’accueil.</p><div><Link href="/" className="button-primary" data-testid="link-not-found-home">Retour à l’accueil <ArrowRight size={17} /></Link><Link href="/profils" className="text-link" data-testid="link-not-found-profiles">Voir les profils</Link></div></main>;
}

function RoutedErrorBoundary({ children }: { children: ReactNode }) {
  const [location] = useLocation();
  return <ErrorBoundary resetKey={location}>{children}</ErrorBoundary>;
}

export default App;
