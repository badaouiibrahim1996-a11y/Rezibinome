import { useState, type FormEvent } from 'react';
import { t } from '@/i18n';
import { ArrowRight, BookOpen, Mail, ShieldCheck } from 'lucide-react';
import { useLocation } from 'wouter';
import { formatSupabaseError } from '@/lib/profiles';
import { supabase } from '@/lib/supabase';

type LoginPageProps = {
  returnTo?: string;
};

export default function LoginPage({ returnTo }: LoginPageProps) {
  const [location, setLocation] = useLocation();
  const target = returnTo ?? (location === '/login' ? '/' : location);
  const [mode, setMode] = useState<'login' | 'signup'>('login');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [busy, setBusy] = useState(false);
  const [notice, setNotice] = useState('');
  const [error, setError] = useState('');

  const submit = async (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    setBusy(true);
    setError('');
    setNotice('');

    if (!supabase) {
      setError(t('La connexion Supabase n’est pas configurée pour ce site.'));
      setBusy(false);
      return;
    }

    try {
      const normalizedEmail = email.trim().toLowerCase();
      if (mode === 'signup') {
        const { data, error: authError } = await supabase.auth.signUp({
          email: normalizedEmail,
          password,
        });
        if (authError) throw authError;
        if (data.session) {
          setLocation(target);
        } else {
          setNotice(
            t('Compte créé. Vérifie ta boîte mail pour confirmer ton adresse, puis connecte-toi.'),
          );
          setMode('login');
        }
      } else {
        const { error: authError } = await supabase.auth.signInWithPassword({
          email: normalizedEmail,
          password,
        });
        if (authError) throw authError;
        setLocation(target);
      }
    } catch (authError) {
      setError(
        formatSupabaseError(
          authError instanceof Error ? authError : { message: String(authError) },
        ),
      );
    } finally {
      setBusy(false);
    }
  };

  return (
    <main className="auth-page">
      <section className="auth-card form-card" aria-labelledby="auth-title">
        <div className="auth-mark"><BookOpen size={24} /></div>
        <div className="eyebrow"><span className="pulse-dot" /> {' '}{t('TON ESPACE RÉSIDANAT')}</div>
        <h1 id="auth-title">
          {mode === 'login' ? t('Content de te revoir.') : t('Crée ton espace.')}
        </h1>
        <p className="auth-copy">
          {t('Connecte-toi pour gérer ton profil et trouver un binôme de révision.')}
        </p>

        <form className="auth-form" onSubmit={submit} data-testid="form-auth">
          <label className="form-field">
            <span>{t('Adresse e-mail')}</span>
            <div className="auth-input-wrap">
              <Mail size={17} aria-hidden="true" />
              <input
                type="email"
                autoComplete="email"
                required
                value={email}
                onChange={(event) => setEmail(event.target.value)}
                placeholder={t('toi@exemple.com')}
                aria-label={t('Adresse e-mail')}
                data-testid="input-auth-email"
              />
            </div>
          </label>
          <label className="form-field">
            <span>{t('Mot de passe')}</span>
            <input
              type="password"
              autoComplete={mode === 'login' ? 'current-password' : 'new-password'}
              minLength={8}
              required
              value={password}
              onChange={(event) => setPassword(event.target.value)}
              placeholder={t('8 caractères minimum')}
              aria-label={t('Mot de passe')}
              data-testid="input-auth-password"
            />
          </label>

          {notice && <div className="auth-alert auth-alert-success" role="status" data-testid="status-auth-notice">{notice}</div>}
          {error && <div className="auth-alert auth-alert-error" role="alert" data-testid="status-auth-error">{error}</div>}

          <button className="button-primary auth-submit" type="submit" disabled={busy} data-testid="button-auth-submit">
            {busy
              ? t('Un instant…')
              : mode === 'login'
                ? t('Se connecter')
                : t('Créer mon compte')}
            <ArrowRight size={17} />
          </button>
        </form>

        <button
          className="button-quiet auth-mode-toggle"
          type="button"
          onClick={() => {
            setMode(mode === 'login' ? 'signup' : 'login');
            setError('');
            setNotice('');
          }}
          data-testid="button-auth-toggle"
        >
          {mode === 'login'
            ? t('Pas encore de compte ? Créer un compte')
            : t('Déjà un compte ? Se connecter')}
        </button>

        <div className="auth-privacy">
          <ShieldCheck size={16} />
          <span>{t('Ton mot de passe reste géré par Supabase Auth.')}</span>
        </div>
      </section>
    </main>
  );
}
