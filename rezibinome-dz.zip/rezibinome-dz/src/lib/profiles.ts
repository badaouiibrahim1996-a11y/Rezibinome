export type Profile = {
  id: string;
  firstName: string;
  wilaya: string;
  university: string;
  subjects: string[];
  allSubjects: boolean;
  level: string;
  studyType: string;
  availability: string[];
  notes: string;
  createdAt: string | null;
  lastActiveAt: string | null;
  gender: 'male' | 'female' | null;
};

export type ProfileInput = Pick<
  Profile,
  | 'firstName'
  | 'wilaya'
  | 'university'
  | 'subjects'
  | 'allSubjects'
  | 'level'
  | 'studyType'
  | 'availability'
  | 'notes'
> & {
  telegram: string;
  whatsapp: string;
  contactEmail: string;
  gender: 'male' | 'female' | '';
};

export const SUBJECTS = [
  'Anatomie',
  'Anatomopathologie',
  'Biochimie',
  'Cardiologie',
  'Chirurgie',
  'Dermatologie',
  'Endocrinologie',
  'Gastro-entérologie',
  'Gynécologie-obstétrique',
  'Hématologie',
  'Immunologie',
  'Infectieux',
  'Médecine interne',
  'Néphrologie',
  'Neurologie',
  'Ophtalmologie',
  'ORL',
  'Orthopédie',
  'Parasitologie',
  'Pédiatrie',
  'Pharmacologie',
  'Physiologie',
  'Pneumologie',
  'Psychiatrie',
  'Radiologie',
  'Réanimation',
  'Rhumatologie',
  'Urgences',
  'Urologie',
] as const;

export const WILAYAS = [
  'Adrar',
  'Chlef',
  'Laghouat',
  'Oum El Bouaghi',
  'Batna',
  'Béjaïa',
  'Biskra',
  'Béchar',
  'Blida',
  'Bouira',
  'Tamanrasset',
  'Tébessa',
  'Tlemcen',
  'Tiaret',
  'Tizi Ouzou',
  'Alger',
  'Djelfa',
  'Jijel',
  'Sétif',
  'Saïda',
  'Skikda',
  'Sidi Bel Abbès',
  'Annaba',
  'Guelma',
  'Constantine',
  'Médéa',
  'Mostaganem',
  "M'Sila",
  'Mascara',
  'Ouargla',
  'Oran',
  'El Bayadh',
  'Illizi',
  'Bordj Bou Arréridj',
  'Boumerdès',
  'El Tarf',
  'Tindouf',
  'Tissemsilt',
  'El Oued',
  'Khenchela',
  'Souk Ahras',
  'Tipaza',
  'Mila',
  'Aïn Defla',
  'Naâma',
  'Aïn Témouchent',
  'Ghardaïa',
  'Relizane',
  'Timimoun',
  'Bordj Badji Mokhtar',
  'Ouled Djellal',
  'Béni Abbès',
  'In Salah',
  'In Guezzam',
  'Touggourt',
  'Djanet',
  "El M'Ghair",
  'El Meniaa',
] as const;

export const UNIVERSITIES = [
  'Alger 1',
  'Sciences de la santé Alger',
  'Constantine 3',
  'Oran 1',
  'Annaba',
  'Tlemcen',
  'Sétif 1',
  'Tizi Ouzou',
  'Sidi Bel Abbès',
  'Blida 1',
  'Batna 2',
  'Laghouat',
  'Ouargla',
  'Béchar',
  'Mostaganem',
  'Béjaïa',
  'Chlef',
  "M'Sila",
  'Djelfa',
  'Tiaret',
  'Biskra',
  'El Oued',
  'Skikda',
  'Jijel',
  'Médéa',
  'Mascara',
  'Oum El Bouaghi',
  'Adrar',
  'Tébessa',
  'Autre',
] as const;

export const STUDY_TYPES = ['Distanciel', 'Présentiel', 'Hybride'] as const;

export type ProfileRow = {
  user_id: string;
  name: string;
  wilaya: string;
  university: string | null;
  subjects: string[] | null;
  all_subjects: boolean | null;
  level: string | null;
  study_type: string | null;
  availability: string[] | null;
  notes: string | null;
  created_at: string | null;
  updated_at: string | null;
  last_active_at: string | null;
  gender?: string | null;
};

export const PROFILE_COLUMNS =
  'user_id,name,wilaya,university,subjects,all_subjects,level,study_type,availability,notes,created_at,last_active_at';

// La colonne « gender » est optionnelle : si elle n’existe pas encore dans Supabase, le site continue de fonctionner sans elle.
export const profileSchema = { gender: true };
export function profileColumns() {
  return profileSchema.gender ? `${PROFILE_COLUMNS},gender` : PROFILE_COLUMNS;
}
export function isMissingGenderColumn(error: { message?: string } | null | undefined) {
  return Boolean(error && /gender/i.test(error.message ?? ''));
}

export function profileFromRow(row: ProfileRow): Profile {
  return {
    id: row.user_id,
    firstName: row.name,
    wilaya: row.wilaya,
    university: row.university ?? '',
    subjects: Array.isArray(row.subjects) ? row.subjects : [],
    allSubjects: row.all_subjects === true,
    level: row.level || 'Niveau non renseigné',
    studyType: row.study_type ?? '',
    availability: Array.isArray(row.availability) ? row.availability : [],
    notes: row.notes ?? '',
    createdAt: row.created_at,
    lastActiveAt: row.last_active_at,
    gender: row.gender === 'male' || row.gender === 'female' ? row.gender : null,
  };
}

export function compatibilityScore(profile: Profile, own: Profile | null) {
  if (!own) return { subjects: 0, times: 0, total: 0 };
  const subjects =
    profile.allSubjects && own.allSubjects
      ? SUBJECTS.length
      : profile.allSubjects
        ? own.subjects.length
        : own.allSubjects
          ? profile.subjects.length
          : profile.subjects.filter((subject) => own.subjects.includes(subject))
              .length;
  const times = profile.availability.filter((slot) =>
    own.availability.includes(slot),
  ).length;
  return { subjects, times, total: subjects + times };
}

export function relativeDate(value: string | null) {
  if (!value) return 'date inconnue';
  const timestamp = new Date(value).getTime();
  if (!Number.isFinite(timestamp)) return 'date inconnue';

  const elapsedSeconds = Math.max(0, Math.floor((Date.now() - timestamp) / 1000));
  if (elapsedSeconds < 24 * 60 * 60) return 'aujourd’hui';

  const units: [Intl.RelativeTimeFormatUnit, number][] = [
    ['year', 365 * 24 * 60 * 60],
    ['month', 30 * 24 * 60 * 60],
    ['week', 7 * 24 * 60 * 60],
    ['day', 24 * 60 * 60],
  ];
  const formatter = new Intl.RelativeTimeFormat('fr-DZ', { numeric: 'always' });
  const [unit, secondsPerUnit] =
    units.find(([, seconds]) => elapsedSeconds >= seconds) ?? units[3];

  return formatter.format(-Math.floor(elapsedSeconds / secondsPerUnit), unit);
}

export function profileDateLabel(label: 'Publié' | 'Actif', value: string | null) {
  return `${label} ${relativeDate(value)}`;
}

export function formatSupabaseError(error: { message?: string } | null | undefined) {
  const message = error?.message?.trim();
  if (!message) return 'Une erreur inattendue est survenue. Réessaie.';

  if (/column .* does not exist|could not find the .* column/i.test(message)) {
    return `Colonne Supabase manquante : ${message}. Aucun changement n’a été fait au schéma.`;
  }
  if (/relation .* does not exist|could not find the table/i.test(message)) {
    return `Table Supabase manquante : ${message}. Aucun changement n’a été fait au schéma.`;
  }
  if (/function .* does not exist|could not find the function/i.test(message)) {
    return `Fonction Supabase manquante : ${message}. Aucun changement n’a été fait au schéma.`;
  }

  return message;
}

export const OTHER_SUBJECT_FILTER = '__autre__';

export function normalizeSubjectName(value: string) {
  const cleaned = value.replace(/[\u0000-\u001f\u007f]/g, ' ').replace(/\s+/g, ' ').trim().slice(0, 40);
  if (!cleaned) return '';
  return cleaned.charAt(0).toLocaleUpperCase('fr') + cleaned.slice(1);
}

export function subjectKey(value: string) {
  return value.normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLocaleLowerCase('fr').replace(/\s+/g, ' ').trim();
}

export function isListedSubject(value: string) {
  return (SUBJECTS as readonly string[]).includes(value);
}

export function findListedSubject(value: string): string | null {
  const key = subjectKey(value);
  return SUBJECTS.find((subject) => subjectKey(subject) === key) ?? null;
}
