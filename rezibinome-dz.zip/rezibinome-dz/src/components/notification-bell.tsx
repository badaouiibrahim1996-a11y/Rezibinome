import { useEffect, useRef, useState } from 'react';
import { Bell, CheckCheck } from 'lucide-react';
import { useLocation } from 'wouter';
import {
  notificationTarget,
  notificationText,
  openGroupSession,
  timeAgo,
  type AppNotification,
  type NotificationsState,
} from '@/lib/notifications';

export default function NotificationBell({
  state,
  actorName,
}: {
  state: NotificationsState;
  actorName: (id: string | null) => string;
}) {
  const [open, setOpen] = useState(false);
  const [, setLocation] = useLocation();
  const wrapRef = useRef<HTMLDivElement | null>(null);

  useEffect(() => {
    if (!open) return undefined;
    const onDown = (event: MouseEvent | TouchEvent) => {
      if (wrapRef.current && !wrapRef.current.contains(event.target as Node)) setOpen(false);
    };
    const onKey = (event: KeyboardEvent) => { if (event.key === 'Escape') setOpen(false); };
    document.addEventListener('mousedown', onDown);
    document.addEventListener('touchstart', onDown);
    document.addEventListener('keydown', onKey);
    return () => {
      document.removeEventListener('mousedown', onDown);
      document.removeEventListener('touchstart', onDown);
      document.removeEventListener('keydown', onKey);
    };
  }, [open]);

  const openItem = (item: AppNotification) => {
    void state.markRead(item.id);
    setOpen(false);
    if (item.kind.startsWith('group_')) openGroupSession(item.ref_id);
    setLocation(notificationTarget(item));
  };

  const badge = state.unread > 9 ? '9+' : String(state.unread);
  return <div className="notif-wrap" ref={wrapRef}>
    <button
      className="icon-button notif-trigger"
      type="button"
      onClick={() => { setOpen((value) => !value); if (!open) void state.refresh(); }}
      aria-label={state.unread > 0 ? `Notifications, ${state.unread} non lue${state.unread > 1 ? 's' : ''}` : 'Notifications'}
      aria-expanded={open}
      data-testid="button-notifications"
    >
      <Bell size={20} />
      {state.unread > 0 && <span className="notif-badge" data-testid="badge-notifications-count">{badge}</span>}
    </button>
    {open && <div className="notif-panel" role="dialog" aria-label="Notifications" data-testid="panel-notifications">
      <div className="notif-head">
        <strong>Notifications</strong>
        <button className="button-quiet button-small" type="button" disabled={state.unread === 0} onClick={() => { void state.markAllRead(); }} data-testid="button-notifications-read-all"><CheckCheck size={15} />Tout marquer comme lu</button>
      </div>
      {state.loading && state.items.length === 0 ? <p className="notif-empty" role="status">Chargement…</p>
        : state.items.length === 0 ? <p className="notif-empty" data-testid="text-notifications-empty">Aucune notification pour le moment.</p>
          : <ul className="notif-list">
            {state.items.map((item) => <li key={item.id}>
              <button className={`notif-item ${item.read_at ? '' : 'is-unread'}`} type="button" onClick={() => openItem(item)} data-testid={`notification-${item.id}`}>
                <span className="notif-dot" aria-hidden="true" />
                <span className="notif-body">
                  <span className="notif-text">{notificationText(item, actorName(item.actor_id))}</span>
                  <span className="notif-time">{timeAgo(item.created_at)}</span>
                </span>
              </button>
            </li>)}
          </ul>}
    </div>}
  </div>;
}
