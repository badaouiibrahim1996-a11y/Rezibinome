import { Moon, Sun } from 'lucide-react';
import { t, useI18n } from '@/i18n';

/** Boutons de langue (français / arabe) et de mode nuit. Le choix est mémorisé sur l’appareil. */
export default function PreferenceButtons() {
  const { lang, setLang, theme, setTheme } = useI18n();
  const nextLang = lang === 'ar' ? 'fr' : 'ar';
  return <div className="pref-buttons">
    <button
      className="icon-button pref-lang"
      type="button"
      onClick={() => setLang(nextLang)}
      aria-label={lang === 'ar' ? 'Passer en français' : 'التبديل إلى العربية'}
      title={lang === 'ar' ? 'Français' : 'العربية'}
      data-testid="button-language-toggle"
    >{lang === 'ar' ? 'FR' : 'عربي'}</button>
    <button
      className="icon-button pref-theme"
      type="button"
      onClick={() => setTheme(theme === 'dark' ? 'light' : 'dark')}
      aria-label={theme === 'dark' ? t('Mode jour') : t('Mode nuit')}
      aria-pressed={theme === 'dark'}
      title={theme === 'dark' ? t('Mode jour') : t('Mode nuit')}
      data-testid="button-theme-toggle"
    >{theme === 'dark' ? <Sun size={19} /> : <Moon size={19} />}</button>
  </div>;
}
