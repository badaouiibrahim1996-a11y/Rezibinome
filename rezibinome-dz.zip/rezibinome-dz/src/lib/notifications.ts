import { useCallback, useEffect, useRef, useState } from 'react';
import { locale, t } from '@/i18n';
import { supabase } from '@/lib/supabase';

export type NotificationKind =
  | 'session_proposed'
  | 'session_accepted'
  | 'session_declined'
  | 'session_cancelled'
  | 'group_joined'
  | 'group_full'
  | 'group_cancelled';

export type AppNotification = {
  id: string;
  kind: NotificationKind;
  ref_id: string;
  actor_id: string | null;
  payload: { subject?: string; topic?: string; starts_at?: string } | null;
  created_at: string;
  read_at: string | null;
};

export type NotificationsState = {
  items: AppNotification[];
  unread: number;
  loading: boolean;
  markRead: (id: string) => Promise<void>;
  markAllRead: () => Promise<void>;
  refresh: () => Promise<void>;
};

const COLUMNS = 'id,kind,ref_id,actor_id,payload,created_at,read_at';
const OPEN_EVENT = 'binome:open-group-session';
let pendingGroupOpen: string | null = null;

export function openGroupSession(id: string) {
  pendingGroupOpen = id;
  window.dispatchEvent(new Event(OPEN_EVENT));
}
export function takePendingGroupOpen() {
  const value = pendingGroupOpen;
  pendingGroupOpen = null;
  return value;
}
export const GROUP_OPEN_EVENT = OPEN_EVENT;

export function notificationTarget(item: AppNotification) {
  return item.kind.startsWith('group_') ? '/sessions-ouvertes' : '/sessions';
}

export function notificationText(item: AppNotification, actorName: string) {
  const subject = t(item.payload?.subject ?? 'révision');
  const topic = item.payload?.topic ?? subject;
  switch (item.kind) {
    case 'session_proposed': return t('{0} te propose une session de {1}.', [actorName, subject]);
    case 'session_accepted': return t('{0} a accepté ta proposition de session.', [actorName]);
    case 'session_declined': return t('{0} a refusé ta proposition de session.', [actorName]);
    case 'session_cancelled': return t('{0} a annulé la session de {1}.', [actorName, subject]);
    case 'group_joined': return t('{0} a rejoint ta session « {1} ».', [actorName, topic]);
    case 'group_full': return t('Ta session « {0} » est complète.', [topic]);
    case 'group_cancelled': return t('La session « {0} » a été annulée.', [topic]);
    default: return t('Nouvelle notification.');
  }
}

export function timeAgo(value: string) {
  const seconds = Math.round((new Date(value).getTime() - Date.now()) / 1000);
  const formatter = new Intl.RelativeTimeFormat(locale(), { numeric: 'auto' });
  const abs = Math.abs(seconds);
  if (abs < 60) return t('à l’instant');
  if (abs < 3600) return formatter.format(Math.round(seconds / 60), 'minute');
  if (abs < 86400) return formatter.format(Math.round(seconds / 3600), 'hour');
  return formatter.format(Math.round(seconds / 86400), 'day');
}

function isMissingTable(error: { message?: string; code?: string } | null) {
  if (!error) return false;
  return error.code === '42P01' || error.code === 'PGRST205' || /notifications/i.test(error.message ?? '') && /(does not exist|schema cache|Could not find)/i.test(error.message ?? '');
}

/**
 * Notifications dans l’application (pas des notifications du téléphone).
 * Elles sont créées côté base de données et rechargées toutes les 60 secondes et au retour sur l’onglet.
 * Retourne null tant que la table n’existe pas dans Supabase.
 */
export function useNotifications(userId: string | null, onNewArrived: (count: number) => void): NotificationsState | null {
  const [items, setItems] = useState<AppNotification[]>([]);
  const [available, setAvailable] = useState(true);
  const [loading, setLoading] = useState(false);
  const known = useRef<Set<string> | null>(null);
  const callback = useRef(onNewArrived);
  callback.current = onNewArrived;
  const requestId = useRef(0);
  const mutations = useRef(0);

  const load = useCallback(async () => {
    if (!supabase || !userId) return;
    const current = ++requestId.current;
    const startedAt = mutations.current;
    const { data, error } = await supabase
      .from('notifications')
      .select(COLUMNS)
      .eq('user_id', userId)
      .order('created_at', { ascending: false })
      .limit(30);
    if (requestId.current !== current) return;
    // Une action (lecture) a eu lieu pendant le chargement : ces données sont périmées, on recharge.
    if (mutations.current !== startedAt) { void load(); return; }
    setLoading(false);
    if (error) {
      if (isMissingTable(error)) setAvailable(false);
      return;
    }
    const rows = (data ?? []) as AppNotification[];
    if (known.current) {
      const fresh = rows.filter((row) => !row.read_at && !known.current!.has(row.id));
      if (fresh.length > 0) callback.current(fresh.length);
    }
    known.current = new Set(rows.map((row) => row.id));
    setItems(rows);
  }, [userId]);

  useEffect(() => {
    known.current = null;
    requestId.current += 1;
    setItems([]);
    setAvailable(true);
    if (!userId) return undefined;
    setLoading(true);
    void load();
    const timer = window.setInterval(() => { if (document.visibilityState === 'visible') void load(); }, 60000);
    const onFocus = () => { void load(); };
    window.addEventListener('focus', onFocus);
    return () => { window.clearInterval(timer); window.removeEventListener('focus', onFocus); };
  }, [userId, load]);

  const markRead = useCallback(async (id: string) => {
    if (!supabase || !userId) return;
    const now = new Date().toISOString();
    mutations.current += 1;
    setItems((list) => list.map((item) => (item.id === id && !item.read_at ? { ...item, read_at: now } : item)));
    const { error } = await supabase.from('notifications').update({ read_at: now }).eq('id', id).eq('user_id', userId).select('id');
    if (error) void load();
  }, [userId, load]);

  const markAllRead = useCallback(async () => {
    if (!supabase || !userId) return;
    const now = new Date().toISOString();
    mutations.current += 1;
    setItems((list) => list.map((item) => (item.read_at ? item : { ...item, read_at: now })));
    const { error } = await supabase.from('notifications').update({ read_at: now }).eq('user_id', userId).is('read_at', null).select('id');
    if (error) void load();
  }, [userId, load]);

  if (!userId || !available) return null;
  return { items, unread: items.filter((item) => !item.read_at).length, loading, markRead, markAllRead, refresh: load };
}
