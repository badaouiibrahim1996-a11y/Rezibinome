import { useState, type FormEvent } from 'react';
import { ArrowRight, BookOpen, Mail, ShieldCheck } from 'lucide-react';
import { useLocation } from 'wouter';
import { formatSupabaseError } from '@/lib/profiles';
import { supabase } from '@/lib/supabase';

type LoginPageProps = {
  returnTo?: string;
};

export default function LoginPage({ returnTo = '/mon-profil' }: LoginPageProps) {
  const [, setLocation] = useLocation();
  const [mode, setMode] = useState<'login' | 'signup'>('login');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [busy, setBusy] = useState(false);
  const [notice, setNotice] = useState('');
  const [error, setError] = useState('');

  const submit = async (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    setBusy(true);
    setError('');
    setNotice('');

    if (!supabase) {
      setError('La connexion Supabase n’est pas configurée pour ce site.');
      setBusy(false);
      return;
    }

    try {
      const normalizedEmail = email.trim().toLowerCase();
      if (mode === 'signup') {
        const { data, error: authError } = await supabase.auth.signUp({
          email: normalizedEmail,
          password,
        });
        if (authError) throw authError;
        if (data.session) {
          setLocation(returnTo);
        } else {
          setNotice(
            'Compte créé. Vérifie ta boîte mail pour confirmer ton adresse, puis connecte-toi.',
          );
          setMode('login');
        }
      } else {
        const { error: authError } = await supabase.auth.signInWithPassword({
          email: normalizedEmail,
          password,
        });
        if (authError) throw authError;
        setLocation(returnTo);
      }
    } catch (authError) {
      setError(
        formatSupabaseError(
          authError instanceof Error ? authError : { message: String(authError) },
        ),
      );
    } finally {
      setBusy(false);
    }
  };

  return (
    <main className="auth-page">
      <section className="auth-card form-card" aria-labelledby="auth-title">
        <div className="auth-mark"><BookOpen size={24} /></div>
        <div className="eyebrow"><span className="pulse-dot" /> TON ESPACE RÉSIDANAT</div>
        <h1 id="auth-title">
          {mode === 'login' ? 'Content·e de te revoir.' : 'Crée ton espace.'}
        </h1>
        <p className="auth-copy">
          Connecte-toi pour gérer ton profil et trouver un binôme de révision.
        </p>

        <form className="auth-form" onSubmit={submit} data-testid="form-auth">
          <label className="form-field">
            <span>Adresse e-mail</span>
            <div className="auth-input-wrap">
              <Mail size={17} aria-hidden="true" />
              <input
                type="email"
                autoComplete="email"
                required
                value={email}
                onChange={(event) => setEmail(event.target.value)}
                placeholder="toi@exemple.com"
                aria-label="Adresse e-mail"
                data-testid="input-auth-email"
              />
            </div>
          </label>
          <label className="form-field">
            <span>Mot de passe</span>
            <input
              type="password"
              autoComplete={mode === 'login' ? 'current-password' : 'new-password'}
              minLength={8}
              required
              value={password}
              onChange={(event) => setPassword(event.target.value)}
              placeholder="8 caractères minimum"
              aria-label="Mot de passe"
              data-testid="input-auth-password"
            />
          </label>

          {notice && <div className="auth-alert auth-alert-success" role="status" data-testid="status-auth-notice">{notice}</div>}
          {error && <div className="auth-alert auth-alert-error" role="alert" data-testid="status-auth-error">{error}</div>}

          <button className="button-primary auth-submit" type="submit" disabled={busy} data-testid="button-auth-submit">
            {busy
              ? 'Un instant…'
              : mode === 'login'
                ? 'Se connecter'
                : 'Créer mon compte'}
            <ArrowRight size={17} />
          </button>
        </form>

        <button
          className="button-quiet auth-mode-toggle"
          type="button"
          onClick={() => {
            setMode(mode === 'login' ? 'signup' : 'login');
            setError('');
            setNotice('');
          }}
          data-testid="button-auth-toggle"
        >
          {mode === 'login'
            ? 'Pas encore de compte ? Créer un compte'
            : 'Déjà un compte ? Se connecter'}
        </button>

        <div className="auth-privacy">
          <ShieldCheck size={16} />
          <span>Ton mot de passe reste géré par Supabase Auth.</span>
        </div>
      </section>
    </main>
  );
}
