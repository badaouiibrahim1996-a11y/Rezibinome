import { useCallback, useEffect, useMemo, useRef, useState, type FormEvent } from 'react';
import { Link } from 'wouter';
import { ArrowRight, CalendarDays, ChevronDown, Clock3, Copy, Download, ExternalLink, Lock, Plus, ShieldCheck, Users, Video, X } from 'lucide-react';
import { formatSupabaseError, SUBJECTS, type Profile } from '@/lib/profiles';
import { supabase } from '@/lib/supabase';

type GroupMode = 'meet' | 'jitsi' | 'chat' | 'organisation';
type GroupVisibility = 'public' | 'private';
type GroupSession = {
  id: string;
  creator: string;
  subject: string;
  topic: string;
  visibility: GroupVisibility;
  max_participants: number;
  starts_at: string;
  duration_minutes: number;
  mode: GroupMode;
  details: string | null;
  invite_code: string;
  status: 'open' | 'cancelled';
  created_at: string;
};
type GroupMember = { session_id: string; user_id: string };
type CreateInput = {
  subject: string;
  topic: string;
  visibility: GroupVisibility;
  maxParticipants: number;
  date: string;
  time: string;
  duration: number;
  mode: GroupMode;
  details: string;
  link: string;
};
type Notify = (message: string, tone?: 'success' | 'error') => void;

const SESSION_COLUMNS = 'id,creator,subject,topic,visibility,max_participants,starts_at,duration_minutes,mode,details,invite_code,status,created_at';
const MAX_OPTIONS = [2, 4, 6, 8, 10, 20];
const DURATION_OPTIONS = [
  { value: 30, label: '30 minutes' },
  { value: 60, label: '1 heure' },
  { value: 90, label: '1 h 30' },
  { value: 120, label: '2 heures' },
];
const MODE_OPTIONS: { value: GroupMode; label: string; hint: string; disabled?: boolean }[] = [
  { value: 'meet', label: 'Google Meet', hint: 'audio/vidéo via un lien' },
  { value: 'jitsi', label: 'Jitsi Meet', hint: 'audio/vidéo, lien créé automatiquement' },
  { value: 'chat', label: 'Discussion écrite dans le site', hint: 'bientôt disponible', disabled: true },
  { value: 'organisation', label: 'Organisation uniquement', hint: 'sans appel intégré' },
];
const MODE_LABEL: Record<GroupMode, string> = {
  meet: 'Google Meet',
  jitsi: 'Jitsi Meet',
  chat: 'Discussion écrite',
  organisation: 'Organisation uniquement',
};
const LINK_RULES: Partial<Record<GroupMode, RegExp>> = {
  meet: /^https:\/\/meet\.google\.com\/\S+$/i,
  jitsi: /^https:\/\/meet\.jit\.si\/\S+$/i,
};
const LINK_PLACEHOLDER: Partial<Record<GroupMode, string>> = {
  meet: 'https://meet.google.com/abc-defg-hij',
  jitsi: 'https://meet.jit.si/NomDeLaSalle',
};

function algeriaDateKey(date = new Date()) {
  const parts = new Intl.DateTimeFormat('en', {
    timeZone: 'Africa/Algiers',
    year: 'numeric',
    month: '2-digit',
    day: '2-digit',
  }).formatToParts(date);
  const part = (type: string) => parts.find((item) => item.type === type)?.value ?? '';
  return `${part('year')}-${part('month')}-${part('day')}`;
}

function algeriaLocalDateTimeToIso(date: string, time: string) {
  const [year, month, day] = date.split('-').map(Number);
  const [hour, minute] = time.split(':').map(Number);
  if (![year, month, day, hour, minute].every(Number.isFinite)) {
    throw new Error('Choisis une date et une heure valides.');
  }
  const targetUtc = Date.UTC(year, month - 1, day, hour, minute);
  let timestamp = targetUtc;
  for (let attempt = 0; attempt < 3; attempt += 1) {
    const parts = new Intl.DateTimeFormat('en', {
      timeZone: 'Africa/Algiers',
      year: 'numeric',
      month: '2-digit',
      day: '2-digit',
      hour: '2-digit',
      minute: '2-digit',
      hourCycle: 'h23',
    }).formatToParts(new Date(timestamp));
    const part = (type: string) => Number(parts.find((item) => item.type === type)?.value);
    const shownUtc = Date.UTC(part('year'), part('month') - 1, part('day'), part('hour'), part('minute'));
    timestamp += targetUtc - shownUtc;
  }
  return new Date(timestamp).toISOString();
}

function formatSessionDate(value: string, compact = false) {
  return new Intl.DateTimeFormat('fr-DZ', {
    timeZone: 'Africa/Algiers',
    hourCycle: 'h23',
    ...(compact
      ? { dateStyle: 'medium' as const, timeStyle: 'short' as const }
      : { weekday: 'long' as const, day: 'numeric' as const, month: 'long' as const, year: 'numeric' as const, hour: '2-digit' as const, minute: '2-digit' as const }),
  }).format(new Date(value));
}

function formatDuration(minutes: number) {
  if (minutes < 60) return `${minutes} min`;
  const hours = Math.floor(minutes / 60);
  const rest = minutes % 60;
  return rest ? `${hours} h ${rest}` : `${hours} h`;
}

function endsAt(item: GroupSession) {
  return new Date(item.starts_at).getTime() + item.duration_minutes * 60 * 1000;
}

function jitsiRoomUrl() {
  const alphabet = 'abcdefghjkmnpqrstuvwxyz23456789';
  const bytes = new Uint8Array(14);
  crypto.getRandomValues(bytes);
  const id = Array.from(bytes, (byte) => alphabet[byte % alphabet.length]).join('');
  return `https://meet.jit.si/ReziBinomeDZ-${id}`;
}

function escapeCalendarText(value: string) {
  return value.replace(/\\/g, '\\\\').replace(/\r?\n/g, '\\n').replace(/,/g, '\\,').replace(/;/g, '\\;');
}

function downloadGroupCalendar(item: GroupSession, link?: string) {
  const start = new Date(item.starts_at);
  const end = new Date(endsAt(item));
  const toCalendarDate = (date: Date) => date.toISOString().replace(/[-:]/g, '').replace(/\.\d{3}Z$/, 'Z');
  const description = [item.details?.trim(), link ? `Lien : ${link}` : ''].filter(Boolean).join('\n');
  const lines = [
    'BEGIN:VCALENDAR',
    'VERSION:2.0',
    'PRODID:-//ReziBinome DZ//Groupes//FR',
    'CALSCALE:GREGORIAN',
    'METHOD:PUBLISH',
    'BEGIN:VEVENT',
    `UID:${escapeCalendarText(item.id)}@rezibinome-dz`,
    `DTSTAMP:${toCalendarDate(new Date())}`,
    `DTSTART:${toCalendarDate(start)}`,
    `DTEND:${toCalendarDate(end)}`,
    `SUMMARY:${escapeCalendarText(`Révision — ${item.subject} : ${item.topic}`)}`,
    `DESCRIPTION:${escapeCalendarText(description)}`,
    'END:VEVENT',
    'END:VCALENDAR',
  ];
  const url = URL.createObjectURL(new Blob([lines.join('\r\n')], { type: 'text/calendar;charset=utf-8' }));
  const anchor = document.createElement('a');
  anchor.href = url;
  anchor.download = `session-groupe-${start.toISOString().slice(0, 10)}.ics`;
  document.body.appendChild(anchor);
  anchor.click();
  anchor.remove();
  window.setTimeout(() => URL.revokeObjectURL(url), 1000);
}

function toError(value: unknown) {
  return formatSupabaseError(value instanceof Error ? value : { message: String(value) });
}

export default function GroupSessionsPage({
  userId,
  own,
  profiles,
  blockedIds,
  notify,
}: {
  userId: string;
  own: Profile | null;
  profiles: Profile[];
  blockedIds: string[];
  notify: Notify;
}) {
  const [sessions, setSessions] = useState<GroupSession[]>([]);
  const [members, setMembers] = useState<GroupMember[]>([]);
  const [links, setLinks] = useState<Record<string, string>>({});
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [tab, setTab] = useState<'open' | 'mine'>('open');
  const [subjectFilter, setSubjectFilter] = useState('');
  const [creating, setCreating] = useState(false);
  const [codeOpen, setCodeOpen] = useState(false);
  const [selectedId, setSelectedId] = useState<string | null>(null);
  const loadId = useRef(0);

  const load = useCallback(async () => {
    const current = ++loadId.current;
    if (!supabase) {
      setError('La connexion Supabase n’est pas configurée.');
      setLoading(false);
      return;
    }
    setError('');
    const since = new Date(Date.now() - 24 * 60 * 60 * 1000).toISOString();
    const { data, error: sessionsError } = await supabase
      .from('group_sessions')
      .select(SESSION_COLUMNS)
      .eq('status', 'open')
      .gte('starts_at', since)
      .order('starts_at', { ascending: true })
      .limit(100);
    if (loadId.current !== current) return;
    if (sessionsError) {
      setSessions([]);
      setMembers([]);
      setLinks({});
      setError(formatSupabaseError(sessionsError));
      setLoading(false);
      return;
    }
    const rows = (data ?? []) as GroupSession[];
    const ids = rows.map((row) => row.id);
    let nextMembers: GroupMember[] = [];
    const nextLinks: Record<string, string> = {};
    if (ids.length) {
      const [membersResult, linksResult] = await Promise.all([
        supabase.from('group_session_members').select('session_id,user_id').in('session_id', ids),
        supabase.from('group_session_links').select('session_id,url').in('session_id', ids),
      ]);
      if (loadId.current !== current) return;
      if (membersResult.error) {
        setError(formatSupabaseError(membersResult.error));
      } else {
        nextMembers = (membersResult.data ?? []) as GroupMember[];
      }
      if (!linksResult.error) {
        ((linksResult.data ?? []) as { session_id: string; url: string }[]).forEach((row) => {
          nextLinks[row.session_id] = row.url;
        });
      }
    }
    setSessions(rows);
    setMembers(nextMembers);
    setLinks(nextLinks);
    setLoading(false);
  }, []);

  useEffect(() => {
    void load();
  }, [load]);

  const membersBySession = useMemo(() => {
    const map = new Map<string, string[]>();
    members.forEach((row) => {
      const list = map.get(row.session_id) ?? [];
      list.push(row.user_id);
      map.set(row.session_id, list);
    });
    return map;
  }, [members]);
  const profileById = useMemo(() => new Map(profiles.map((profile) => [profile.id, profile])), [profiles]);
  const live = useMemo(
    () => sessions.filter((item) => endsAt(item) >= Date.now() && !blockedIds.includes(item.creator)),
    [sessions, blockedIds],
  );
  const publicSessions = live.filter((item) => item.visibility === 'public');
  const openList = publicSessions.filter((item) => !subjectFilter || item.subject === subjectFilter);
  const mineList = live.filter((item) => membersBySession.get(item.id)?.includes(userId));
  const shown = tab === 'open' ? openList : mineList;
  const participantsTotal = publicSessions.reduce((sum, item) => sum + (membersBySession.get(item.id)?.length ?? 0), 0);
  const selected = live.find((item) => item.id === selectedId) ?? null;

  const create = async (input: CreateInput) => {
    if (!supabase) throw new Error('La connexion Supabase n’est pas configurée.');
    if (!own) throw new Error('Crée ton profil avant de créer une session.');
    const startsAt = algeriaLocalDateTimeToIso(input.date, input.time);
    if (new Date(startsAt).getTime() <= Date.now()) throw new Error('Choisis une date et une heure dans le futur.');
    const { data, error: insertError } = await supabase
      .from('group_sessions')
      .insert({
        creator: userId,
        subject: input.subject,
        topic: input.topic.trim(),
        visibility: input.visibility,
        max_participants: input.maxParticipants,
        starts_at: startsAt,
        duration_minutes: input.duration,
        mode: input.mode,
        details: input.details.trim() || null,
      })
      .select('id')
      .single();
    if (insertError) throw new Error(formatSupabaseError(insertError));
    const newId = (data as { id: string }).id;
    const link = input.mode === 'jitsi' ? jitsiRoomUrl() : input.mode === 'meet' ? input.link.trim() : '';
    let linkFailed = false;
    if (link) {
      const { error: linkError } = await supabase.from('group_session_links').insert({ session_id: newId, url: link });
      linkFailed = Boolean(linkError);
    }
    await load();
    setCreating(false);
    setTab('mine');
    notify(linkFailed
      ? 'Ta session est créée, mais le lien n’a pas pu être enregistré. Ajoute-le depuis la session.'
      : 'Ta session a été créée.', linkFailed ? 'error' : 'success');
  };

  const join = async (sessionId: string) => {
    if (!supabase) throw new Error('La connexion Supabase n’est pas configurée.');
    const { error: joinError } = await supabase.rpc('join_group_session', { p_session_id: sessionId });
    if (joinError) throw new Error(formatSupabaseError(joinError));
    await load();
    notify('Tu as rejoint la session.');
  };

  const joinByCode = async (code: string) => {
    if (!supabase) throw new Error('La connexion Supabase n’est pas configurée.');
    const { data, error: joinError } = await supabase.rpc('join_group_session', { p_code: code });
    if (joinError) throw new Error(formatSupabaseError(joinError));
    await load();
    setCodeOpen(false);
    setTab('mine');
    if (typeof data === 'string') setSelectedId(data);
    notify('Tu as rejoint la session.');
  };

  const leave = async (sessionId: string) => {
    if (!supabase) throw new Error('La connexion Supabase n’est pas configurée.');
    const { error: leaveError } = await supabase
      .from('group_session_members')
      .delete()
      .eq('session_id', sessionId)
      .eq('user_id', userId);
    if (leaveError) throw new Error(formatSupabaseError(leaveError));
    await load();
    notify('Tu as quitté la session.');
  };

  const cancel = async (sessionId: string) => {
    if (!supabase) throw new Error('La connexion Supabase n’est pas configurée.');
    const { error: cancelError } = await supabase.from('group_sessions').update({ status: 'cancelled' }).eq('id', sessionId);
    if (cancelError) throw new Error(formatSupabaseError(cancelError));
    setSelectedId(null);
    await load();
    notify('La session a été annulée.');
  };

  const saveLink = async (sessionId: string, url: string) => {
    if (!supabase) throw new Error('La connexion Supabase n’est pas configurée.');
    const { error: linkError } = await supabase
      .from('group_session_links')
      .upsert({ session_id: sessionId, url, updated_at: new Date().toISOString() }, { onConflict: 'session_id' });
    if (linkError) throw new Error(formatSupabaseError(linkError));
    await load();
    notify('Le lien a été enregistré.');
  };

  return <main className="browse-page relationship-page sessions-page group-sessions-page">
    <section className="page-heading">
      <div className="page-heading-inner">
        <div>
          <div className="eyebrow"><span className="pulse-dot" /> RÉVISIONS EN GROUPE</div>
          <h1>Sessions ouvertes</h1>
          <p>Trouve un groupe et révise ensemble.</p>
        </div>
        <div className="profile-count"><strong>{publicSessions.length}</strong><span>ouvertes</span><Users size={20} /></div>
      </div>
    </section>
    <section className="browse-content">
      {error && <div className="data-error" role="alert" data-testid="status-group-error">{error}</div>}
      {!own && <div className="data-error" role="status" data-testid="status-group-need-profile">Crée d’abord ton profil pour créer ou rejoindre une session. <Link href="/mon-profil" className="text-link">Aller à mon profil</Link></div>}
      <div className="gs-stats">
        <div className="gs-stat"><Users size={18} /><strong>{participantsTotal}</strong><span>Participants</span></div>
        <div className="gs-stat"><CalendarDays size={18} /><strong>{publicSessions.length}</strong><span>Sessions ouvertes</span></div>
      </div>
      <div className="gs-toolbar">
        <button className="button-primary button-small" type="button" disabled={!own} onClick={() => setCreating(true)} data-testid="button-create-group-session">Créer une session <Plus size={16} /></button>
        <button className="button-light button-small gs-code-button" type="button" disabled={!own} onClick={() => setCodeOpen(true)} data-testid="button-join-by-code"><Lock size={15} />Rejoindre avec un code</button>
      </div>
      <div className="session-tabs" role="tablist" aria-label="Filtrer les sessions de groupe">
        <button className={`button-quiet session-tab ${tab === 'open' ? 'active' : ''}`} type="button" role="tab" aria-selected={tab === 'open'} onClick={() => setTab('open')} data-testid="tab-group-open">Ouvertes<span className="session-tab-count">{openList.length}</span></button>
        <button className={`button-quiet session-tab ${tab === 'mine' ? 'active' : ''}`} type="button" role="tab" aria-selected={tab === 'mine'} onClick={() => setTab('mine')} data-testid="tab-group-mine">Mes inscriptions<span className="session-tab-count">{mineList.length}</span></button>
      </div>
      {tab === 'open' && <label className="form-field select-form-field gs-filter">
        <span>Matière</span>
        <select value={subjectFilter} onChange={(event) => setSubjectFilter(event.target.value)} aria-label="Filtrer par matière" data-testid="select-group-subject-filter">
          <option value="">Toutes les matières</option>
          {SUBJECTS.map((subject) => <option key={subject} value={subject}>{subject}</option>)}
        </select>
        <ChevronDown size={17} />
      </label>}
      {loading ? <div className="loading-state" role="status" data-testid="status-group-loading">Chargement des sessions…</div> :
        error ? null : shown.length ? <div className="gs-list">{shown.map((item) => {
          const memberIds = membersBySession.get(item.id) ?? [];
          return <GroupSessionCard
            key={item.id}
            item={item}
            count={memberIds.length}
            creatorName={profileById.get(item.creator)?.firstName ?? 'Étudiant·e'}
            isMember={memberIds.includes(userId)}
            onOpen={() => setSelectedId(item.id)}
          />;
        })}</div> :
          <div className="empty-state request-empty" data-testid={`status-no-group-${tab}`}>
            <div className="empty-icon"><Users size={24} /></div>
            <h3>{tab === 'open' ? 'Aucune session ouverte' : 'Aucune inscription'}</h3>
            <p>{tab === 'open' ? 'Crée la première session et invite tes binômes à te rejoindre.' : 'Les sessions que tu rejoins ou que tu crées apparaîtront ici.'}</p>
          </div>}
      <p className="privacy-note"><ShieldCheck size={14} />Le lien de réunion n’est visible que par les participants inscrits.</p>
    </section>
    {creating && <CreateGroupDialog onClose={() => setCreating(false)} onSubmit={create} />}
    {codeOpen && <JoinCodeDialog onClose={() => setCodeOpen(false)} onSubmit={joinByCode} />}
    {selected && <GroupSessionDialog
      item={selected}
      userId={userId}
      canJoin={Boolean(own)}
      memberNames={(membersBySession.get(selected.id) ?? []).map((id) => ({ id, name: profileById.get(id)?.firstName ?? 'Étudiant·e' }))}
      link={links[selected.id] ?? ''}
      creatorName={profileById.get(selected.creator)?.firstName ?? 'Étudiant·e'}
      onClose={() => setSelectedId(null)}
      onJoin={join}
      onLeave={leave}
      onCancel={cancel}
      onSaveLink={saveLink}
      onCopy={(text) => {
        navigator.clipboard.writeText(text)
          .then(() => notify('Copié'))
          .catch(() => notify('Impossible de copier sur cet appareil.', 'error'));
      }}
    />}
  </main>;
}

function GroupSessionCard({
  item,
  count,
  creatorName,
  isMember,
  onOpen,
}: {
  item: GroupSession;
  count: number;
  creatorName: string;
  isMember: boolean;
  onOpen: () => void;
}) {
  const full = count >= item.max_participants;
  const percent = Math.min(100, Math.round((count / item.max_participants) * 100));
  return <article className="gs-card" data-testid={`card-group-session-${item.id}`}>
    <div className="gs-card-top">
      <span className="gs-chip">{item.subject}</span>
      <span className={`gs-status ${isMember ? 'is-member' : full ? 'is-full' : 'is-open'}`}>{isMember ? 'Inscrit·e' : full ? 'Complète' : 'Ouverte'}</span>
    </div>
    <h3>{item.topic}</h3>
    <p className="gs-meta"><CalendarDays size={15} /><time dateTime={item.starts_at}>{formatSessionDate(item.starts_at, true)}</time></p>
    <p className="gs-meta"><Clock3 size={15} />{formatDuration(item.duration_minutes)} · {MODE_LABEL[item.mode]}</p>
    <p className="gs-meta"><Users size={15} />Organisée par {creatorName}</p>
    <div className="gs-progress" role="progressbar" aria-valuemin={0} aria-valuemax={item.max_participants} aria-valuenow={count}><span style={{ width: `${percent}%` }} /></div>
    <div className="gs-count">
      <span>{count} / {item.max_participants} participants</span>
      {item.visibility === 'private' && <span className="gs-private"><Lock size={12} />Privée</span>}
    </div>
    <button className={`${isMember || full ? 'button-light' : 'button-primary'} button-small gs-open`} type="button" onClick={onOpen} data-testid={`button-open-group-session-${item.id}`}>{isMember || full ? 'Voir la session' : 'Voir la session et rejoindre'}</button>
  </article>;
}

function useEscape(onClose: () => void, disabled: boolean) {
  useEffect(() => {
    const close = (event: KeyboardEvent) => { if (event.key === 'Escape' && !disabled) onClose(); };
    window.addEventListener('keydown', close);
    return () => window.removeEventListener('keydown', close);
  }, [disabled, onClose]);
}

function GroupSessionDialog({
  item,
  userId,
  canJoin,
  memberNames,
  link,
  creatorName,
  onClose,
  onJoin,
  onLeave,
  onCancel,
  onSaveLink,
  onCopy,
}: {
  item: GroupSession;
  userId: string;
  canJoin: boolean;
  memberNames: { id: string; name: string }[];
  link: string;
  creatorName: string;
  onClose: () => void;
  onJoin: (sessionId: string) => Promise<void>;
  onLeave: (sessionId: string) => Promise<void>;
  onCancel: (sessionId: string) => Promise<void>;
  onSaveLink: (sessionId: string, url: string) => Promise<void>;
  onCopy: (text: string) => void;
}) {
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');
  const [confirmCancel, setConfirmCancel] = useState(false);
  const [linkDraft, setLinkDraft] = useState(link);
  const isMember = memberNames.some((member) => member.id === userId);
  const isCreator = item.creator === userId;
  const full = memberNames.length >= item.max_participants;
  const hasCall = item.mode === 'meet' || item.mode === 'jitsi';
  useEscape(onClose, busy);

  const run = async (action: () => Promise<void>) => {
    setError('');
    setBusy(true);
    try {
      await action();
    } catch (actionError) {
      setError(toError(actionError));
    } finally {
      setBusy(false);
    }
  };

  const submitLink = (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    const rule = LINK_RULES[item.mode];
    const value = linkDraft.trim();
    if (!rule || !rule.test(value)) {
      setError(item.mode === 'jitsi' ? 'Le lien doit commencer par https://meet.jit.si/' : 'Le lien doit commencer par https://meet.google.com/');
      return;
    }
    void run(() => onSaveLink(item.id, value));
  };

  return <div className="dialog-overlay" role="presentation" onMouseDown={(event) => { if (event.target === event.currentTarget && !busy) onClose(); }} data-testid="dialog-group-session-overlay">
    <section className="contact-dialog gs-dialog" role="dialog" aria-modal="true" aria-labelledby="group-session-title" data-testid="dialog-group-session">
      <button className="icon-button dialog-close" type="button" onClick={onClose} aria-label="Fermer" disabled={busy} data-testid="button-close-group-session"><X size={19} /></button>
      <div className="dialog-icon"><Users size={23} /></div>
      <div className="dialog-eyebrow">{item.subject.toUpperCase()} · {item.visibility === 'private' ? 'SESSION PRIVÉE' : 'SESSION PUBLIQUE'}</div>
      <h2 id="group-session-title">{item.topic}</h2>
      <ul className="gs-details">
        <li><CalendarDays size={15} />{formatSessionDate(item.starts_at)}</li>
        <li><Clock3 size={15} />{formatDuration(item.duration_minutes)} · heure d’Algérie</li>
        <li><Video size={15} />{MODE_LABEL[item.mode]}</li>
        <li><Users size={15} />{memberNames.length} / {item.max_participants} participants · organisée par {creatorName}</li>
      </ul>
      {item.details?.trim() && <blockquote className="gs-note">{item.details}</blockquote>}
      <div className="gs-participants">
        {memberNames.map((member) => <span key={member.id} className="gs-chip">{member.name}{member.id === item.creator ? ' (organisateur·rice)' : ''}</span>)}
      </div>

      {item.visibility === 'private' && isMember && <div className="gs-code-box">
        <span>Code d’invitation</span>
        <strong data-testid="text-group-invite-code">{item.invite_code}</strong>
        <button className="button-light button-small" type="button" onClick={() => onCopy(item.invite_code)} data-testid="button-copy-invite-code"><Copy size={14} />Copier</button>
      </div>}

      {hasCall && isMember && (link
        ? <a className="button-primary button-small gs-call" href={link} target="_blank" rel="noopener noreferrer" data-testid="link-group-call"><Video size={15} />Rejoindre l’appel<ExternalLink size={14} /></a>
        : <p className="gs-hint">Le lien de la réunion n’a pas encore été ajouté.</p>)}
      {hasCall && !isMember && <p className="gs-hint">Le lien de la réunion s’affiche après avoir rejoint la session.</p>}

      {hasCall && isCreator && <form className="relationship-dialog-form gs-link-form" onSubmit={submitLink} noValidate>
        <label className="form-field"><span>{link ? 'Modifier le lien de la réunion' : 'Ajouter le lien de la réunion'}</span>
          <input type="url" value={linkDraft} onChange={(event) => setLinkDraft(event.target.value)} placeholder={LINK_PLACEHOLDER[item.mode]} aria-label="Lien de la réunion" data-testid="input-group-link" />
        </label>
        <div className="dialog-actions gs-link-actions">
          <button className="button-primary button-small" type="submit" disabled={busy} data-testid="button-save-group-link">Enregistrer le lien</button>
          {item.mode === 'jitsi' && <button className="button-light button-small" type="button" disabled={busy} onClick={() => setLinkDraft(jitsiRoomUrl())} data-testid="button-generate-jitsi">Générer un lien Jitsi</button>}
        </div>
      </form>}

      {error && <div className="form-error dialog-error" role="alert" data-testid="status-group-dialog-error">{error}</div>}
      <div className="dialog-actions gs-actions">
        {!isMember && <button className="button-primary button-small" type="button" disabled={busy || full || !canJoin} onClick={() => { void run(() => onJoin(item.id)); }} data-testid="button-join-group-session">{busy ? 'Traitement…' : full ? 'Session complète' : 'Rejoindre la session'} <ArrowRight size={16} /></button>}
        {isMember && <button className="button-light button-small" type="button" onClick={() => downloadGroupCalendar(item, link || undefined)} data-testid="button-group-calendar"><Download size={15} />Ajouter au calendrier</button>}
        {isMember && !isCreator && <button className="button-quiet button-small" type="button" disabled={busy} onClick={() => { void run(() => onLeave(item.id)); }} data-testid="button-leave-group-session">Quitter la session</button>}
        {isCreator && !confirmCancel && <button className="button-quiet button-small" type="button" disabled={busy} onClick={() => setConfirmCancel(true)} data-testid="button-cancel-group-session">Annuler la session</button>}
        {isCreator && confirmCancel && <>
          <button className="button-danger button-small" type="button" disabled={busy} onClick={() => { void run(() => onCancel(item.id)); }} data-testid="button-confirm-cancel-group-session">{busy ? 'Annulation…' : 'Confirmer l’annulation'}</button>
          <button className="button-quiet button-small" type="button" disabled={busy} onClick={() => setConfirmCancel(false)}>Garder la session</button>
        </>}
      </div>
    </section>
  </div>;
}

function CreateGroupDialog({ onClose, onSubmit }: { onClose: () => void; onSubmit: (input: CreateInput) => Promise<void> }) {
  const [subject, setSubject] = useState('');
  const [topic, setTopic] = useState('');
  const [visibility, setVisibility] = useState<GroupVisibility>('public');
  const [maxParticipants, setMaxParticipants] = useState(8);
  const [date, setDate] = useState('');
  const [time, setTime] = useState('20:00');
  const [duration, setDuration] = useState(60);
  const [mode, setMode] = useState<GroupMode>('meet');
  const [link, setLink] = useState('');
  const [details, setDetails] = useState('');
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');
  useEscape(onClose, busy);

  const submit = async (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    setError('');
    if (!subject) { setError('Choisis la matière médicale.'); return; }
    if (topic.trim().length < 3) { setError('Écris le sujet de la séance (3 caractères minimum).'); return; }
    if (!date || !time) { setError('Renseigne la date et l’heure.'); return; }
    if (mode === 'meet' && link.trim() && !LINK_RULES.meet?.test(link.trim())) {
      setError('Le lien Google Meet doit commencer par https://meet.google.com/');
      return;
    }
    setBusy(true);
    try {
      await onSubmit({ subject, topic, visibility, maxParticipants, date, time, duration, mode, details, link });
    } catch (submitError) {
      setError(toError(submitError));
      setBusy(false);
    }
  };

  return <div className="dialog-overlay" role="presentation" onMouseDown={(event) => { if (event.target === event.currentTarget && !busy) onClose(); }} data-testid="dialog-create-group-overlay">
    <section className="contact-dialog gs-dialog" role="dialog" aria-modal="true" aria-labelledby="create-group-title" data-testid="dialog-create-group">
      <button className="icon-button dialog-close" type="button" onClick={onClose} aria-label="Fermer" disabled={busy} data-testid="button-close-create-group"><X size={19} /></button>
      <div className="dialog-icon"><CalendarDays size={23} /></div>
      <div className="dialog-eyebrow">RÉVISIONS EN GROUPE</div>
      <h2 id="create-group-title">Créer une session</h2>
      <p className="dialog-copy">Organise une révision collective pour le résidanat.</p>
      <form className="relationship-dialog-form" onSubmit={(event) => { void submit(event); }} noValidate>
        <label className="form-field select-form-field"><span>1. Matière médicale <i>*</i></span>
          <select value={subject} onChange={(event) => setSubject(event.target.value)} aria-label="Matière médicale" data-testid="select-group-subject">
            <option value="">Choisir une matière</option>
            {SUBJECTS.map((item) => <option key={item} value={item}>{item}</option>)}
          </select>
          <ChevronDown size={17} />
        </label>
        <label className="form-field"><span>2. Sujet de la séance <i>*</i></span>
          <input type="text" value={topic} maxLength={80} onChange={(event) => setTopic(event.target.value)} placeholder="Ex. QCM — Insuffisance cardiaque" aria-label="Sujet de la séance" data-testid="input-group-topic" />
        </label>

        <fieldset className="gs-fieldset"><legend>3. Visibilité <i>*</i></legend>
          <label className="gs-radio"><input type="radio" name="gs-visibility" checked={visibility === 'public'} onChange={() => setVisibility('public')} data-testid="radio-group-public" /><span><b>Publique</b><small>Visible dans la liste des sessions ouvertes.</small></span></label>
          <label className="gs-radio"><input type="radio" name="gs-visibility" checked={visibility === 'private'} onChange={() => setVisibility('private')} data-testid="radio-group-private" /><span><b>Privée</b><small>Accessible avec un code d’invitation que tu partages.</small></span></label>
        </fieldset>

        <fieldset className="gs-fieldset"><legend>4. Nombre maximal de participants <i>*</i></legend>
          <div className="gs-radio-row">
            {MAX_OPTIONS.map((value) => <label key={value} className="gs-radio gs-radio-compact"><input type="radio" name="gs-max" checked={maxParticipants === value} onChange={() => setMaxParticipants(value)} data-testid={`radio-group-max-${value}`} /><span>{value}</span></label>)}
          </div>
        </fieldset>

        <div className="session-form-grid">
          <label className="form-field"><span>5. Date <i>*</i></span><input type="date" value={date} min={algeriaDateKey()} onChange={(event) => setDate(event.target.value)} aria-label="Date de la session" data-testid="input-group-date" /></label>
          <label className="form-field"><span>6. Heure (Algérie) <i>*</i></span><input type="time" value={time} onChange={(event) => setTime(event.target.value)} aria-label="Heure de la session" data-testid="input-group-time" /></label>
        </div>

        <fieldset className="gs-fieldset"><legend>7. Durée <i>*</i></legend>
          <div className="gs-radio-row">
            {DURATION_OPTIONS.map((option) => <label key={option.value} className="gs-radio gs-radio-compact"><input type="radio" name="gs-duration" checked={duration === option.value} onChange={() => setDuration(option.value)} data-testid={`radio-group-duration-${option.value}`} /><span>{option.label}</span></label>)}
          </div>
        </fieldset>

        <fieldset className="gs-fieldset"><legend>8. Mode de révision</legend>
          {MODE_OPTIONS.map((option) => <label key={option.value} className={`gs-radio ${option.disabled ? 'is-disabled' : ''}`}><input type="radio" name="gs-mode" checked={mode === option.value} disabled={option.disabled} onChange={() => setMode(option.value)} data-testid={`radio-group-mode-${option.value}`} /><span><b>{option.label}</b><small>{option.hint}</small></span></label>)}
          {mode === 'meet' && <label className="form-field gs-link-field"><span>Lien Google Meet (facultatif, tu peux l’ajouter plus tard)</span>
            <input type="url" value={link} onChange={(event) => setLink(event.target.value)} placeholder={LINK_PLACEHOLDER.meet} aria-label="Lien Google Meet" data-testid="input-group-create-link" />
          </label>}
          <p className="gs-hint">Le lien de réunion est visible uniquement par les participants inscrits.</p>
        </fieldset>

        <label className="form-field"><span>9. Informations complémentaires (facultatif)</span>
          <textarea value={details} maxLength={300} rows={3} onChange={(event) => setDetails(event.target.value)} placeholder="Ex. Préparer 20 QCM, lire le cours avant la séance" aria-label="Informations complémentaires" data-testid="textarea-group-details" />
        </label>
        <span className="character-count">{details.length}/300 caractères</span>

        {error && <div className="form-error dialog-error" role="alert" data-testid="status-create-group-error">{error}</div>}
        <div className="dialog-actions">
          <button className="button-primary button-small" type="submit" disabled={busy} data-testid="button-submit-create-group">{busy ? 'Création…' : 'Créer la session'} <ArrowRight size={16} /></button>
          <button className="button-light button-small" type="button" onClick={onClose} disabled={busy}>Annuler</button>
        </div>
      </form>
      <div className="dialog-footnote"><ShieldCheck size={15} />Les horaires sont en heure d’Algérie (Africa/Algiers).</div>
    </section>
  </div>;
}

function JoinCodeDialog({ onClose, onSubmit }: { onClose: () => void; onSubmit: (code: string) => Promise<void> }) {
  const [code, setCode] = useState('');
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');
  useEscape(onClose, busy);

  const submit = async (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    setError('');
    const value = code.trim().toUpperCase();
    if (value.length < 6) { setError('Saisis le code d’invitation reçu.'); return; }
    setBusy(true);
    try {
      await onSubmit(value);
    } catch (submitError) {
      setError(toError(submitError));
      setBusy(false);
    }
  };

  return <div className="dialog-overlay" role="presentation" onMouseDown={(event) => { if (event.target === event.currentTarget && !busy) onClose(); }} data-testid="dialog-join-code-overlay">
    <section className="contact-dialog" role="dialog" aria-modal="true" aria-labelledby="join-code-title" data-testid="dialog-join-code">
      <button className="icon-button dialog-close" type="button" onClick={onClose} aria-label="Fermer" disabled={busy} data-testid="button-close-join-code"><X size={19} /></button>
      <div className="dialog-icon"><Lock size={23} /></div>
      <div className="dialog-eyebrow">SESSION PRIVÉE</div>
      <h2 id="join-code-title">Rejoindre avec un code</h2>
      <p className="dialog-copy">Saisis le code d’invitation que l’organisateur·rice t’a envoyé.</p>
      <form className="relationship-dialog-form" onSubmit={(event) => { void submit(event); }} noValidate>
        <label className="form-field"><span>Code d’invitation</span>
          <input type="text" value={code} maxLength={12} autoCapitalize="characters" autoComplete="off" onChange={(event) => setCode(event.target.value.toUpperCase())} placeholder="Ex. A1B2C3D4" aria-label="Code d’invitation" data-testid="input-group-code" />
        </label>
        {error && <div className="form-error dialog-error" role="alert" data-testid="status-join-code-error">{error}</div>}
        <div className="dialog-actions">
          <button className="button-primary button-small" type="submit" disabled={busy} data-testid="button-submit-join-code">{busy ? 'Vérification…' : 'Rejoindre'} <ArrowRight size={16} /></button>
          <button className="button-light button-small" type="button" onClick={onClose} disabled={busy}>Annuler</button>
        </div>
      </form>
    </section>
  </div>;
}
