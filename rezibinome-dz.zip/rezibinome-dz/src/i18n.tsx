import { createContext, useCallback, useContext, useEffect, useMemo, useState, type ReactNode } from 'react';
import { AR } from '@/i18n-ar';

export type Lang = 'fr' | 'ar';
export type Theme = 'light' | 'dark';

const LANG_KEY = 'binome-lang';
const THEME_KEY = 'binome-theme';

function readStorage(key: string) {
  try { return window.localStorage.getItem(key); } catch { return null; }
}
function writeStorage(key: string, value: string) {
  try { window.localStorage.setItem(key, value); } catch { /* stockage indisponible : le choix vaut pour cette session */ }
}

function initialLang(): Lang {
  const saved = readStorage(LANG_KEY);
  return saved === 'ar' ? 'ar' : 'fr';
}
function initialTheme(): Theme {
  return readStorage(THEME_KEY) === 'dark' ? 'dark' : 'light';
}

let currentLang: Lang = typeof window === 'undefined' ? 'fr' : initialLang();

export const getLang = () => currentLang;
export const locale = () => (currentLang === 'ar' ? 'ar-DZ' : 'fr-DZ');

/** Traduit un texte écrit en français. Les variables {0}, {1}… sont remplacées dans l’ordre. */
export function t(key: string, vars?: ReadonlyArray<string | number>): string {
  const raw = currentLang === 'ar' ? (AR[key] ?? key) : key;
  if (!vars || vars.length === 0) return raw;
  return raw.replace(/\{(\d+)\}/g, (_match, index: string) => String(vars[Number(index)] ?? ''));
}

/** Nom d’université : certaines portent le même nom qu’une wilaya, d’où la clé séparée. */
export function tu(name: string): string {
  if (currentLang !== 'ar') return name;
  return AR['u:' + name] ?? name;
}

type I18nValue = { lang: Lang; setLang: (lang: Lang) => void; theme: Theme; setTheme: (theme: Theme) => void };
const Ctx = createContext<I18nValue>({ lang: 'fr', setLang: () => {}, theme: 'light', setTheme: () => {} });

export function I18nProvider({ children }: { children: ReactNode }) {
  const [lang, setLangState] = useState<Lang>(() => currentLang);
  const [theme, setThemeState] = useState<Theme>(initialTheme);
  currentLang = lang;

  useEffect(() => {
    const root = document.documentElement;
    root.lang = lang;
    root.dir = lang === 'ar' ? 'rtl' : 'ltr';
    root.dataset.lang = lang;
  }, [lang]);

  useEffect(() => {
    const root = document.documentElement;
    root.dataset.theme = theme;
    root.style.colorScheme = theme;
    const meta = document.querySelector('meta[name="theme-color"]');
    if (meta) meta.setAttribute('content', theme === 'dark' ? '#0f1b24' : '#f4f9fb');
  }, [theme]);

  const setLang = useCallback((next: Lang) => { currentLang = next; writeStorage(LANG_KEY, next); setLangState(next); }, []);
  const setTheme = useCallback((next: Theme) => { writeStorage(THEME_KEY, next); setThemeState(next); }, []);
  const value = useMemo(() => ({ lang, setLang, theme, setTheme }), [lang, setLang, theme, setTheme]);
  return <Ctx.Provider value={value}>{children}</Ctx.Provider>;
}

export function useI18n() {
  return useContext(Ctx);
}
